#by Aidan Tristen R. Angel
#ID Number 026226627
#CECS 451

import random
from board import Board
import time


def genetic_algorithm(boards):

    #Variable that will store the best solution board (aka the board with a get_fitness of 0
    final_board = None
    start_time = time.time()  # Records the starting time

    #While loop is used to make the algorithm continously test until it finds a solution.
    while True:
        #Checks the fitness of each board that is given to the algorithm via main.
        board_fitness = [board.get_fitness() for board in boards]
        #An empty list to store potential solutions rows/lists for each iteration.
        potential_solutions = []

        #Iterates through the current generation of boards
        for i in range(len(boards)):
            #Selection function is called to randomly select 2 parents or "boards"
            b1, b2 = selection(boards, board_fitness, 2)
            #retrieves the maps of b1 and b2 to be cross, thus the name "genes"
            b1_genes = b1.map
            b2_genes = b2.map
            #calls the cross function to intersplice or "cross" the two chosen board's map to find create a new board
            child_genes = cross(b1_genes, b2_genes)
            #randomly mutates the "child genes" to add diversity.
            child = mutate(child_genes)
            #appends the genes to the potential solutions list for comparison.
            potential_solutions.append(child)

        #Now, the solutions are not yet actually boards, but instead lists that can be
        #initialized and transformed into boards, or rather, board objects.
        final_boards = conversion_to_boards(potential_solutions)

        #Iterate through final_boards and checks the fitness of each board to find a 0 get_fitness
        #or best board/solution
        for board in final_boards:
            if board.get_fitness() == 0:
                final_board = board
                break  # Exits the inner loop when a board with a fitness 0 is found

        if final_board:
            break  # Exit the outer loop when a board with a fitness 0 is found

    # Records how long it took the algorithm to find the best solution board.
    end_time = time.time()
    #Converts the time to miliseconds and also to a single digit time for easier reading.
    run_time = int((end_time - start_time) * 1000)
    #Prints out the time, and the solution board to be seen.
    print("Running time:", f"{run_time:} ms")
    # print("Solution")
    for row in final_board.get_map():
        print(" ".join(["-" if x == 0 else "1" for x in row]))

#Cross function
def cross(b1_genes, b2_genes):
    #Takes the length of the genes of the parents, (you can call either or as the length should be the same>)
    n = len(b1_genes)
    #Code to randomly choose a crossover point.
    crossover_point = random.randint(1, n - 1)
    #Combines the genes of both parents based on the crossover point.
    #Before the point for b1, and after the point for b2
    child_genes = b1_genes[:crossover_point] + b2_genes[crossover_point:]

    #returns the newly made child_genes
    return child_genes

#Mutation Function
def mutate(gene_to_be_mutated):
    #Sets the probability of Mutation (the higher this is, the higher the chance for mutation.
    mutation_rate = 0.1

    #randomly selects a list (in this case, the child genes) to be mutated
    selected_list = random.choice(gene_to_be_mutated)

    #Determines if a mutation should occur, and double checks if there is a one in the list.
    if random.random() < mutation_rate:
        #Finds the index where 1 is
        one_index = selected_list.index(1)

        #looks at the indexes that are valid to mutate
        valid_indices = [i for i in range(len(selected_list))]
        #Chooses a new index
        new_index = random.choice(valid_indices)
        #makes the index where 1 was initially found a 0
        selected_list[one_index] = 0
        #replaces whatever index was selected with a 1.
        selected_list[new_index] = 1

    #returns gene to be mutated
    return gene_to_be_mutated

#selection function.
def selection(boards, board_fitness, num):
    #randomly chooses the boards to be selected based on board_fitness, and how many boards are to be chosen.
    choices = random.choices(boards, weights=board_fitness, k=num)
    #returns the chosen boards.
    return choices

#Function to Convert Potential Solutions into boards
def conversion_to_boards(potential_solutions):
    #creates an empty list to store "Board" objects
    boards = []
    #Iterates through the potential solutions, looking at each solution
    for solution in potential_solutions:
        #creates a board that is based on the size of the solution (in this case, 5x5)
        board = Board(len(solution))
        #sets the map of the board to the genes of the current solution aka assigns the queens to the board.
        board.map = solution
        #places the newly made board into the list for storage and comparisons
        boards.append(board)
    #retuns the list of boards
    return boards


if __name__ == '__main__':
    num_of_states_allowed = 8  # sets how many boards are to be created initially and for each subequent generation.
    boards = [Board(5) for _ in range(num_of_states_allowed)] #creates the boards based on num_of_states_allowed.

    #calls the algorithm to be run.
    best_solution = genetic_algorithm(boards)

#Rayyan Ashraf 

import random
import time
from board import Board

def get_best_neighbor(board):
    best_fitness = float('inf')
    best_board = None
    for i in range(board.n_queen):
        current_j = [j for j in range(board.n_queen) if board.map[i][j] == 1][0]
        for j in range(board.n_queen):
            if j != current_j:  # Avoid the current position of the queen
                new_board = Board(board.n_queen)
                new_board.map = [row[:] for row in board.map]
                # Move the queen within the row
                new_board.map[i][current_j] = 0
                new_board.map[i][j] = 1
                fitness = new_board.get_fitness()
                if fitness < best_fitness:
                    best_fitness = fitness
                    best_board = new_board
    return best_board

def hill_climbing_optimized(initial_state):
    current = initial_state
    while True:
        neighbor = get_best_neighbor(current)
        if neighbor.get_fitness() >= current.get_fitness():
            return current
        current = neighbor

if __name__ == "__main__":
    start_time = time.time()
    initial_board = Board(5)
    solution_board = hill_climbing_optimized(initial_board)
    end_time = time.time()
    print(f"Running time: {int((end_time - start_time) * 1000)}ms")
    for row in solution_board.map:
        print(' '.join(['1' if cell == 1 else '-' for cell in row]))

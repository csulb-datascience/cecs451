import time
from random import randrange
from random import randint
from random import random
import board


def genetic(game: board.Board):
    # Generate the random states
    genes = []
    for i in range(8):
        genes.append(generate_state())

    solved = False
    while not solved:
        # Get the fitness of all the states
        fitness = dict()
        for i in range(len(genes)):
            fitness_value = test_fitness(genes[i])
            # Check if any of the genes have a perfect fitness
            if fitness_value == 0:
                solved = True
                gene = genes[i]
                # Set the game board values to that gene
                # Set all values to 0
                for j in range(game.n_queen):
                    for k in range(game.n_queen):
                        if game.get_map()[j][k] == 1:
                            game.flip(j, k)

                # Set the values according to the gene
                for j in range(game.n_queen):
                    game.flip(j, int(gene[j]))
                break

            fitness[i] = fitness_value

        # Perform the check if it has been solved to avoid the rest of the loop
        if solved:
            break

        # Select the states
        genes = selection(fitness, genes)

        # Cross over the states
        genes = crossover(genes)

        # Mutation
        genes = mutation(genes)

        # Check if any of the genes have solved
        for gene in genes:
            if test_fitness(gene) == 0:
                solved = True
                # Set the game board values to that gene
                # Set all values to 0
                for i in range(game.n_queen):
                    for j in range(game.n_queen):
                        if game.get_map()[i][j] == 1:
                            game.flip(i, j)

                # Set the values according to the gene
                for i in range(game.n_queen):
                    game.flip(i, int(gene[i]))
                break


def test_fitness(gene: str) -> int:
    test = board.Board(5)

    # Set all values to 0
    for i in range(test.n_queen):
        for j in range(test.n_queen):
            if test.get_map()[i][j] == 1:
                test.flip(i, j)

    # Set the values according to the gene
    for i in range(test.n_queen):
        test.flip(i, int(gene[i]))

    # Return the fitness
    return test.get_fitness()


def selection(fitness: dict, genes: []) -> []:
    probabilities = []
    fitness_values = []

    # Calculate the fitness values of each gene
    for i in range(len(fitness)):
        fitness_value = 10 - fitness[i]
        fitness_values.append(fitness_value)

    # Fitness cannot equal 0 because it was checked earlier
    # Therefore do not have to worry about probability of 1.
    # Assign probabilities to each gene
    total_fitness = sum(fitness_values)
    for i in range(len(fitness)):
        probability = fitness_values[i] / total_fitness
        probabilities.append(probability)

    # Now select genes based on probabilities
    selected = []
    for i in range(len(fitness)):
        probability = random()
        # Accumulator keeps track of probabilities
        accumulator = 0
        for j in range(len(probabilities)):
            # If the probability has occurred, select that gene
            if probability <= accumulator + probabilities[j]:
                selected.append(genes[j])
                break
            # Due to probability potentially not adding up to 1 due to being floats,
            # if element is the last, append to list.
            elif j == len(probabilities) - 1:
                selected.append(genes[j])
                break
            else:
                accumulator = accumulator + probabilities[j]

    return selected


def crossover(genes: []) -> []:
    # Pair genes by using a step of 2
    for i in range(0, len(genes), 2):
        split_index = randint(1, 4)
        temp_copy = genes[i]
        # Cross over the first gene
        genes[i] = genes[i][0:split_index] + genes[i + 1][split_index:5]
        # Cross over the second gene
        genes[i + 1] = genes[i + 1][0:split_index] + temp_copy[split_index:5]

    return genes


def mutation(genes: []) -> []:
    for i in range(len(genes)):
        mutation_index = randint(-1, 4)
        # if -1 do not mutate
        if mutation_index == -1:
            continue
        elif mutation_index == 0:
            genes[i] = str(randint(0, 4)) + genes[i][1:5]
        elif mutation_index == 4:
            genes[i] = genes[i][0:4] + str(randint(0, 4))
        else:
            genes[i] = genes[i][0:mutation_index] + str(randint(0, 4)) + genes[i][mutation_index + 1: 5]

    return genes


def generate_state() -> str:
    gene = ''
    for i in range(5):
        gene += str(randrange(5))
    return gene


def main():
    # Get the start time
    start_time = time.perf_counter()
    # Initialize the board
    game = board.Board(5)
    # Start algorithm
    genetic(game)
    # Get the end time
    end_time = time.perf_counter()

    # Calculate running time and round to the nearest ms
    running_time = round((end_time - start_time) * 1000)

    print("Running time:", str(running_time) + "ms")

    # Print the board
    for i in range(game.n_queen):
        for j in range(game.n_queen):
            if j == game.n_queen - 1:
                if game.get_map()[i][j] == 0:
                    print('-')
                else:
                    print('1')
            elif game.get_map()[i][j] == 0:
                print('- ', end='')
            else:
                print('1 ', end='')


if __name__ == '__main__':
    main()

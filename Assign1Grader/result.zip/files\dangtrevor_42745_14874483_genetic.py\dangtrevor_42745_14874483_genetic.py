# Trevor Dang CECS-451 Assignment 2 Local Search 2/16/2024
from board import Board
import time
import random

#creates an initial population with a certain number of states with the given amount of queens
def init_pop(states, n_queen):
    return [Board(n_queen) for i in range(states)]

#selection function for the genetic algorithm that selects based on relative proportion and random
def select(states):
    #allows for sum of relative proportion equal to a total prob of 1
    total_fit = sum(1 / (board.get_fitness() + 1) for board in states)
    total_prob = []
    total_sum = 0
    
    #adds up the total probability for each state
    for board in states:
        curr_fit = 1 / (board.get_fitness() + 1)
        total_sum += curr_fit / total_fit
        total_prob.append(total_sum)
 
    #randomly selects state from relative proportion, with lower fitness states being better
    rand_select = random.random()
    for i, prob in enumerate(total_prob):
        if rand_select <= prob:
            return states[i]

#crossover function that splits the states at a random index and swaps them
def cross(parent1, parent2):
    parent1_size = len(parent1.map)
    #random split
    split = random.randint(1, parent1_size - 1)
    #new children boards created to inherit from parents
    child1, child2 = Board(parent1_size), Board(parent1_size)

    #parents boards are split and swaped to make children boards
    for i in range(split):
        child1.map[i], child2.map[i] = parent1.map[i][:], parent2.map[i][:]
    for i in range(split, parent1_size):
        child1.map[i], child2.map[i] = parent2.map[i][:], parent1.map[i][:]
    return child1, child2

#mutation function that chooses a random column to change theh queen in each row
def mutate(board, mutate_rate = 0.1):
    board_size = len(board.map)

    #mutation probability check for the entire board then iterates over each row in the board
    if random.random() < mutate_rate:
        for row in range(board_size):
            #chooses a new random column for queen
            rand_column = random.randint(0, board_size - 1)
            #clears the row to place the queen in the selected random column
            board.map[row] = [0] * board_size
            board.map[row][rand_column] = 1

#genetic algorithm that uses selection, crossover, and mutation
def genetic_algo(states, n_queen, gen):
    #initializes the population
     inital_pop = init_pop(states, n_queen)
     for i in range(gen):
        new_pop = []

        #loop to fill the new population with selection, crossover, and mutation
        while len(new_pop) < states:
            parent1 = select(inital_pop)
            parent2 = select(inital_pop)
            child1, child2 = cross(parent1, parent2)
            mutate(child1)
            mutate(child2)
            new_pop.extend([child1, child2])

        #replaces the initial population with the new one
        inital_pop = new_pop

    #returns the state lowest fitness score
     return min(inital_pop, key = lambda x: x.get_fitness())

def main():
    board = Board(5)

    start_time_ms = time.time()
    optimal = genetic_algo(8, 5, 2000)
    end_time_ms = time.time()
    total_runtime = round((end_time_ms - start_time_ms) * 1000, 2)
    
    print(f"Running time: {total_runtime} ms")
    for row in optimal.get_map():
        print(' '.join('-' if m == 0 else '1' for m in row))

if __name__ == "__main__":
    main()
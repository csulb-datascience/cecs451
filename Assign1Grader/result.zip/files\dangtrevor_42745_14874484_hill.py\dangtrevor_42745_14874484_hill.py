# Trevor Dang CECS-451 Assignment 2 Local Search 2/16/2024
from board import Board
import time

#hill climbing algorithm with random restart implemented
def rand_restart_hill_algo(initial, rand_restart):
    optimal = None
    optimal_fit = float('inf')

    #starts the hill climbing algorithm with a specified number of random restarts
    for i in range(rand_restart):
        curr = initial
        #loops to start the hill climbing algorithm
        while True:
            #gets the surrounding neighbors of the initial board
            neighbors = get_neighbors(curr)
            #finds the neighbor with the lowest fitness and if lower than curret, current fitness is set as the new lowest fitness
            lowest = min(neighbors, key = lambda curr: curr.get_fitness())
            if lowest.get_fitness() <= curr.get_fitness():
                curr = lowest
            else:
                break

        #if current fitness ever gets to 0 (which we want) it will return current
        if curr.get_fitness() == 0:
            return curr

        #makes sure the current board is better than a past board
        if curr.get_fitness() < optimal_fit:
            optimal = curr
            optimal_fit = curr.get_fitness()

    return optimal

#get neighbors is used to get all the one-move neighbors of the board
def get_neighbors(board):
    neighbors = []
    #iterates through each row and column
    for i in range(board.n_queen):
        for j in range(board.n_queen):
            #checks for queen
            if board.map[i][j] == 1:
                #new loop that finds a different column for the queen to move to
                for k in range(board.n_queen):
                    #checks for same column
                    if k != j:
                        #if not same, then creates a new board with updated moves
                        new = Board(board.n_queen)
                        new.map = [row[:] for row in board.map]
                        new.map[i][j] = 0
                        new.map[i][k] = 1
                        neighbors.append(new)
    return neighbors


def main():
    board = Board(5)

    start_time_ms = time.time()
    optimal = rand_restart_hill_algo(board, 100)
    end_time_ms = time.time()
    total_runtime = round((end_time_ms - start_time_ms) * 1000, 2)

    print(f"Running time: {total_runtime} ms")
    for row in optimal.get_map():
        print(' '.join('-' if m == 0 else '1' for m in row))

if __name__ == "__main__":
    main()

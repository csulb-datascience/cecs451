# Diego Delgado
# hill assignment Assignment2
# CECS 451 Artificial Intelligence
# Spring 2024
import random
import numpy as np
import copy
import timeit
from board import Board

# moves queen to other potential spots
# depends on row
# check where queen is on specific row, 
# create 4 new boards with queen moved to new spots 
# all other queens remain untouched

def movePiece(initialBoard, row):
    if row >= 5: 
        row = 0
    # check position of queen in current row
    map = initialBoard.map
    column = 0
    for col in range(len(map[row])):
        if map[row][col] == 1:
            column = col
    # make copies of original board and change queen position
    tempBoard1 = copy.deepcopy(initialBoard)
    tempBoard2 = copy.deepcopy(initialBoard)
    tempBoard3 = copy.deepcopy(initialBoard)
    tempBoard4 = copy.deepcopy(initialBoard)
    boardList = [tempBoard1, tempBoard2, tempBoard3, tempBoard4]
    # create new rows with unique positions for queen
    start = 0
    end = len(map[row]) - 1
    if column == 0:
        start = column + 1
    if column == end:
        end = column - 1
    updatedRows = []
    while(start <= end):
        newRow = [0] * len(map[row])
        if start == column:
            start += 1
            continue
        newRow[start] = 1
        updatedRows.append(newRow)
        start += 1
    # update rows in the copies
    for i in range(len(boardList)):
        boardList[i].map[row] = updatedRows[i]
    # check which board has best fitness
    bestFitness = min(tempBoard1.get_fitness(), tempBoard2.get_fitness(),
                      tempBoard3.get_fitness(), tempBoard4.get_fitness())
    for board in boardList:
        if (board.get_fitness() == 0):
            return board
        elif (board.get_fitness() == bestFitness):
            return movePiece(board, row + 1)

def printSolution(board):
    map = board.get_map()
    for row in map:
        for element in row:
            if element == 0:
                print('-', end=" ")
            else:
                print(element, end=" ")
        print("")



if __name__ == '__main__':
    startTime = timeit.default_timer()
    test = Board(5)
    solution = movePiece(test, 0)
    endTime = timeit.default_timer()
    # print solution
    print("Running time:", round((endTime - startTime) * 1000), end='')
    print("ms")
    printSolution(solution)
# Diego Delgado
# genetic assignment Assignment2
# CECS 451 Artificial Intelligence
# Spring 2024

import random
import numpy as np
import timeit
import copy
from board import Board


# encode boards, should help with overall programming
# turns board into a string
def encodeBoards(parents):
    # encode the boards based on where queen is on each column
    encodedStrings = []
    for parent in parents:
        map = parent.get_map()
        #print(parent.get_fitness())
        string = ''
        for row in map:
            for i in range(len(row)):
                if (row[i] == 1):
                    string = string + str(i)
        encodedStrings.append(string)
        # print(map, string)
    return encodedStrings
# this function should help with overall programming
# will decode string and make a new board out of it
def decodeStrings(encodedStrings):
    boards = []
    for string in encodedStrings:
        board = Board(5)
        board.map = [[0 for j in range(5)] for i in range(5)]
        for i in range(len(board.get_map())):
            board.map[i][int(string[i])] = 1
        boards.append(board)
    return boards
        

# genetic algorithm
def genetic(parents):
    parents2 = copy.deepcopy(parents)
    generation = 0
    bestChildFound = False
    # loops until fitness level of 0 is reached 
    while (not bestChildFound):
        # if generations reaches 1000 start again from initial parents
        if (generation == 1000):
            parents = copy.deepcopy(parents2)
            generation = 0

        encodedParents = encodeBoards(parents)

        # the selection stage
        pairs = selection(parents)

        # the crossover stage
        children = crossover(encodedParents, pairs)

        # the mutation stage
        mutatedChildren = mutation(children)

        # decode the string and check fitness levels
        generation += 1
        #print("generation:", generation)
        childrenBoards = decodeStrings(mutatedChildren)
        # offspring will be added to pool
        for child in childrenBoards:
            #print(child.get_fitness())
            # if fitness is 0 solution found, if not add child to parent pool
            if (child.get_fitness() == 0):
                bestChildFound = True
                return child
            parents.append(child)
    

def selection(parents):
    # the selection process, lower fitness = higher desirability
    maxFitness = max(parent.get_fitness() for parent in parents) + 1
    # we will make probability based on the max fitness level
    parentProbabilities = []
    for parent in parents:
        probability = float((maxFitness - parent.get_fitness()) / maxFitness)
        parentProbabilities.append(probability)
        #print(probability)
    # normalize 
    totalSum = sum(parentProbabilities)
    parentProbabilities = [prob / totalSum for prob in parentProbabilities]
    #print(parentProbabilities)
    # we will make 4 matching pairs
    parentPoolSize = len(parents)
    pair1 = np.random.choice(parentPoolSize, 2, replace=False, p=parentProbabilities)
    pair2 = np.random.choice(parentPoolSize, 2, replace=False, p=parentProbabilities)
    pair3 = np.random.choice(parentPoolSize, 2, replace=False, p=parentProbabilities)
    pair4 = np.random.choice(parentPoolSize, 2, replace=False, p=parentProbabilities)
    pairs = [pair1, pair2, pair3, pair4]
    return pairs

def crossover(encodedParents, pairs):
    randomPivot = random.randint(1,3)
    #print(randomPivot)
    children = []
    #print (encodedParents, pairs)
    # create offspring with random pivot
    for pair in pairs:
        parent1 = str(encodedParents[pair[0]])
        parent2 = str(encodedParents[pair[1]])
        # print(parent1, parent2)
        child1 = parent1[:randomPivot] + parent2[randomPivot:]
        children.append(child1)
        child2 = parent2[:randomPivot] + parent1[randomPivot:]
        children.append(child2)
        # print("children:",child1, child2)
    return children

def mutation(children):
    # set mutation rate at 0.1
    # mutate based on absolute value of 4
    mutatedChildren = []
    mutationRate = 0.10
    for child in children:
        child = list(child)
        for i in range(len(child)):
            mutationChance = random.uniform(0, 1)
            if mutationChance < mutationRate:
                #print("mutation at ", i)
                child[i] = str(abs(int(child[i]) - int(random.uniform(0, 4))))
        child = ''.join(child)
        mutatedChildren.append(child)
        #print(child)
    return mutatedChildren
     

def printSolution(board):
    map = board.get_map()
    for row in map:
        for element in row:
            if element == 0:
                print('-', end=" ")
            else:
                print(element, end=" ")
        print("")



if __name__ == '__main__':
    startTime = timeit.default_timer()
    #create 8 boards
    # these 8 boards will act as the initial parents 
    board1 = Board(5)
    board2 = Board(5)
    board3 = Board(5)
    board4 = Board(5)
    board5 = Board(5)
    board6 = Board(5)
    board7 = Board(5)
    board8 = Board(5)
    parents = [board1, board2, board3, board4, board5, board6, board7, board8]
    solution = genetic(parents)
    endTime = timeit.default_timer()
    # print solution
    print("Running time:", round((endTime - startTime) * 1000), end='')
    print("ms")
    printSolution(solution)
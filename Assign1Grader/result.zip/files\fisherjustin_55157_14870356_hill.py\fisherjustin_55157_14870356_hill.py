from board import Board
import time

def display(board):
    N = board.n_queen
    for i in range(N):
        if i > 0:
            print()
        for j in range(N):
            if board.map[i][j]:
                print(board.map[i][j], end = " ")
            else:
                print("-", end = " ")

# Goal: make h(board) = 0
# We will achieve this by moving the queen in each row and find the smallest h value
# Each row will now have the best heuristic for the current board
# If heuristic isn't 0 we need to restart the board so we don't get stuck in a local minimum

def hillClimb(board:Board):
    attempts = 0
    N = board.n_queen
    while(True):
        attempts+=1
        for row in range(N):
            if(board.get_fitness() == 0 ): return board
            min_h = float("inf")
            #Remove the current queen from the row
            for index, isQueen in enumerate(board.map[row]):
                if isQueen:
                    board.flip(row,index)
                    break

            #Place queen in each column of row and see the heuristic of board
            best_placement = 0
            for column in range(N):
                board.flip(row,column) # place queen
                new_h = board.get_fitness()
                if(new_h == 0): return board
                if new_h < min_h:
                    min_h = new_h
                    best_placement = column
                board.flip(row,column)

            #Now flip the queen with best h
            board.flip(row,best_placement)
        #If attempts == N*10 then we hit a local minimum and need a random restart
        if attempts == N*10:
            board = Board(board.n_queen)
            attempts = 0

    return board




if __name__ == "__main__":
    board = Board(5)

    start_t = time.time()
    board = hillClimb(board)
    end_t = time.time()

    print(f"Running time: {round((end_t - start_t) * 1000)}ms")
    display(board)





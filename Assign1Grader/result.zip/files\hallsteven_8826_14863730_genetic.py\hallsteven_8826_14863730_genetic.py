import time
import random
from board import Board

def generate_initial_state(board):
    return [board.map[i].index(1) for i in range(len(board.map))]

def get_fitness(board):
    return board.get_fitness()

def selection(population, fitnesses):
    index1 = random.choices(range(len(population)), weights=fitnesses)[0]
    index2 = random.choices(range(len(population)), weights=fitnesses)[0]
    parent1 = population[index1]
    parent2 = population[index2]
    return parent1, parent2

def crossover(parent1, parent2):
    n = len(parent1)
    crossover_point = random.randint(1, n - 1)
    offspring1 = parent1[:crossover_point] + parent2[crossover_point:]
    offspring2 = parent2[:crossover_point] + parent1[crossover_point:]
    return offspring1, offspring2

def mutation(state, mutation_rate):
    mutated_state = state[:]
    for i in range(len(mutated_state)):
        if random.random() < mutation_rate:
            mutated_state[i] = random.randint(0, len(state) - 1)
    return mutated_state

def genetic_algorithm(population_size, n_generations, mutation_rate):
    start_time = time.time()
    n_queen = 5
    board = Board(n_queen)
    initial_state = generate_initial_state(board)
    population = [initial_state] * population_size
    for _ in range(n_generations):
        boards = [Board(n_queen) for _ in range(population_size)]
        fitnesses = [get_fitness(board) for board in boards]
        new_population = []
        for _ in range(population_size // 2):
            parent1, parent2 = selection(population, fitnesses)
            offspring1, offspring2 = crossover(parent1, parent2)
            offspring1 = mutation(offspring1, mutation_rate)
            offspring2 = mutation(offspring2, mutation_rate)
            new_population.extend([offspring1, offspring2])
        population = new_population
        for state in population:
            for i, col in enumerate(state):
                board.map[i] = [0] * n_queen
                board.map[i][col] = 1
            if board.get_fitness() == 0:
                running_time = round((time.time() - start_time) * 1000)
                return state, running_time
    best_state = min(population, key=get_fitness)
    running_time = round((time.time() - start_time) * 1000)
    return best_state, running_time

if __name__ == "__main__":
    population_size = 8
    n_generations = 100
    mutation_rate = 0.1
    solution, running_time = genetic_algorithm(population_size, n_generations, mutation_rate)
    print("Running time: {}ms".format(running_time))
    # print("Solution:")
    for col in solution:
        row = ["1" if i == col else "-" for i in range(len(solution))]
        print(" ".join(row))

from board import Board
from time import time
import random

N = 5
# a set of 8 distinct states
# selection
# crossover
# mutation


# changes board into array(maybe change to string later) based on location of queens for each row
def encode(board):
    z = board
    encoded_arr = []
    # print(z.get_map())
    # loop through each row and get position of queen based on their current position on the rwo
    for i in range(N):
        for j in range(N):
            if z.map[i][j] == 1:
                encoded_arr.append(j)
    return encoded_arr


# gets array and places queen based on where the
def decode(arr):
    # produce a board and set it empty
    to_decode = arr
    k = Board(N)
    k.map = [[0 for j in range(N)] for i in range(N)]
    # loop through and place queen based on index of array
    for i in range(N):
        for j in range(N):
            if to_decode[i] == j:
                k.map[i][j] = 1
    # print(k.get_map())
    return k

# determine amount of attacking pairs by doing 10 - get_fitness


def selection(boards, prob):
    # random.choices to select boards randomly while being weighted by a list of weights(probability)
    # print(boards)
    # print('select prob: ', prob)
    x = random.choices(boards, prob, k=8)
    # for i in range(8):
    #     print('selected ', x[i].get_map())
    return x


def crossover(arr1, arr2):
    # find a random spot to splice and change arrays into strings
    rand_index = random.randint(0, N-1)
    arr1_str = [str(ele) for ele in arr1]
    arr2_str = [str(ele) for ele in arr2]
    arr1_join = ''.join(arr1_str)
    arr2_join = ''.join(arr2_str)
    # splice and append to new string
    new_arr1 = arr1_join[:rand_index] + arr2_join[rand_index:]
    new_arr2 = arr2_join[:rand_index] + arr1_join[rand_index:]
    # print('arr1 ', arr1)
    # print('arr2 ', arr2)
    # print('rand splice: ', rand_index)
    # print('after change arr1: ', new_arr1)
    # print('after change arr2: ', new_arr2)
    return new_arr1, new_arr2


def mutation(to_mutate):
    arr_str = []
    mut = []
    # arr_str = list(map(int, to_mutate))
    # index_mut = random.randint(0, N - 1)
    # queen_pos = random.randint(0, N - 1)
    # arr_str[index_mut] = queen_pos
    # return arr_str
    # print(to_mutate)
    # loop through all strings in the list
    for i in range(len(to_mutate)):
        # change string to array of ints
        arr_str = list(map(int, to_mutate[i]))
        # find a random index to change and find random queen to place
        index_mut = random.randint(0, N - 1)
        # print('index to change: ', index_mut)
        queen_pos = random.randint(0, N - 1)
        # print('queens pos: ', queen_pos)
        arr_str[index_mut] = queen_pos
        mut.append(arr_str)
    # print('mutation after: ', mut)
    return mut


def genetic(population, n):
    obj = []
    fitness = []
    prob = []
    encoded = []
    crossed = []
    mutated = []
    decoded = []
    cont = False

    # initialize 8 boards
    obj = [Board(n) for i in range(population)]
    while cont is False:
        # go through each board and append their fitness to get h
        for i in range(population):
            # print(obj[i].get_map())
            if obj[i].get_fitness() == 0:
                return obj[i]
                break
            fitness.append(10 - obj[i].get_fitness())
            # print(obj[i].get_fitness())
            # print('obj before: ', obj[i].get_map())
            # encoded.append(encode(obj[i]))

        # print('fitness ', fitness)
        sum_fit = sum(fitness)
        # print('sum fit', sum_fit)
        for i in range(population):
            prob.append(fitness[i]/sum_fit)
        # print('probability', prob)

        # select 8 random genes based on randomness weighted by probability
        x = selection(obj, prob)
        # cross pairs at random spots
        # change to array before crossing
        for i in range(len(x)):
            encoded.append(encode(x[i]))
        # cross in pairs of 2 based on selected
        for i in range(0, population, 2):
            cross1, cross2 = crossover(encoded[i], encoded[i+1])
            crossed.append(cross1)
            crossed.append(cross2)
        # print('crossed: ', crossed)
        # change random index based on mutation
        mutated = mutation(crossed)
        # need to clear or else boards get appended rather than replacing current boards
        obj.clear()
        for i in range(pop):
            decoded.append(decode(mutated[i]))
            # print('decode', decoded[i].get_map())
            obj.append(decoded[i])
            # print('new obj: ', obj[i].get_map())
        # print('obj len', len(obj))
        # need to clear or else everything is saved and infinite loop
        fitness.clear()
        prob.clear()
        encoded.clear()
        decoded.clear()
        crossed.clear()
        mutated.clear()
        # print('fitness: ', fitness)
        # print('prob', prob)
        # for i in range(pop):
        #     fitness.append(10 - obj[i].get_fitness())
        #     if obj[i].get_fitness() == 0:
        #         return obj[i]
        #         break
        #     print(obj[i].get_fitness())

        # sum_fit = sum(fitness)
        # prob.clear()
        # print('cleared', prob)
        # for i in range(population):
        #     prob.append(fitness[i]/sum_fit)
        # print('prob ', prob)
        # print('fitness: ', fitness)
    return None

# goal is to maximize h (5C2) = 10


def print_map(board):
    for i in range(N):
        for j in range(N):
            if board.map[i][j] == 0:
                board.map[i][j] = "-"
    k = list(board.map)
    str_list = []
    for i in range(N):
        stringify = [str(ele) for ele in k[i]]
        res = ' '.join(stringify)
        str_list.append(res)
    # print(str_list)
    for i in range(N):
        print(str_list[i])


# idea: generate 8 strings randomized from 1-5
# implement a function that converts that string back to a board, perhaps use record function from earlier
if __name__ == "__main__":
    pop = 8

    t0 = time()
    y = genetic(pop, N)
    t1 = time()
    t = (t1 - t0) * 1000
    print('Running Time: ', int(round(t)), 'ms')
    print_map(y)

    # tests before making into actual function
    # init_board = Board(N)
    # x = init_board.get_fitness()
    # rand = random.randint(0, N - 1)
    # x = [4, 3, 2, 4, 0]
    # y = [2, 3, 2, 4, 3]
    # x_str = [str(ele) for ele in x]
    # y_str = [str(ele) for ele in y]
    # x_join = ''.join(x_str)
    # y_join = ''.join(y_str)
    # print(x_join)
    # print(y_join)
    # new_x = x_join[:rand] + y_join[rand:]
    # new_y = y_join[:rand] + x_join[rand:]
    # print(x_join[:rand])
    # print(y_join[:rand])
    # print(new_x)
    # print(new_y)





# Eric Ho-Sing-Loy
# CECS 451 Assign 2.1 - Hill Climbing
# Fri, 2/15/2024

from board import Board
import time
import numpy as np

# find the best successor
def best_successor(board):
    successors = []
    for i in range(board.n_queen):
        for j in range(board.n_queen):
            if board.get_map()[i][j] == 1:
                continue
            new_board = Board(board.n_queen)
            new_board.map = np.copy(board.get_map())
            new_board.flip(i, j)
            successors.append(new_board)
    return min(successors, key=lambda x: x.get_fitness())

# hill-climbing algorithm with random restart mechanism
# if the algorithm does not find the solution, it will restart
def hill_climbing():
    while True:
        board = Board(5)
        while True:
            successor = best_successor(board)
            if successor.get_fitness() >= board.get_fitness():
                break
            board = successor
        if board.get_fitness() == 0:
            return board

if __name__ == '__main__':
    start = time.time()
    solution = hill_climbing()
    end = time.time()
    print("Running time: {:.0f}ms".format((end - start) * 1000))
    for row in solution.get_map():
        print(" ".join("-" if cell==0 else "1" for cell in row))
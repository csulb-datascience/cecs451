# Eric Ho-Sing-Loy
# CECS 451-01 Assign 2.2 - Genetic Algorithm
# Fri, 2/16/2024

from board import Board
import time
import random

# Maximum h value for 5-queen problem
def max_fitness(n):
    # Calculates the maximum fitness value for a the n-queen problem
    ans = n * (n - 1) / 2
    return ans

# Encoding process
def encode(board):
    # Encodes the given board into an encoded board
    encoded_board = Board(5)
    # Iterate over rows of the original board
    for i, row in enumerate(board.get_map()):
        # Numbers 2 to 5 representing empty cells
        empty_cells = list(range(2, 6))
        # Shuffle the list of empty cell values
        random.shuffle(empty_cells)

        # Iterate over cells in the row
        for j, cell in enumerate(row):
            if cell == 1:
                # Queen cell
                encoded_board.map[i][j] = 1
            else:
                # Assign a random empty cell value
                encoded_board.map[i][j] = empty_cells.pop()
    return encoded_board

# Selection process
def selection(states):
    # Selects the states based on their fitness percentage
    fitness = [max_fitness(5) - state.get_fitness() for state in states]
    total_fitness = sum(fitness)
    percentage = [fit / total_fitness for fit in fitness]
    selected_states = []
    for _ in range(8):
        r = random.random()
        for i in range(len(states)):
            if r < sum(percentage[:i + 1]):
                selected_states.append(states[i])
                break
    return selected_states

# Crossover process
def crossover(states):
    # Performs crossover between selected states
    crossed_states = []
    for i in range(0, 8, 2):
        state1 = states[i]
        state2 = states[i + 1]
        new_state1 = Board(5)
        new_state2 = Board(5)
        for j in range(5):
            if random.random() < 0.5:
                new_state1.map[j] = state1.map[j]
                new_state2.map[j] = state2.map[j]
            else:
                new_state1.map[j] = state2.map[j]
                new_state2.map[j] = state1.map[j]
        crossed_states.append(new_state1)
        crossed_states.append(new_state2)
    return crossed_states

# Mutation process
def mutation(states):
    # Mutates the states
    mutated_states = []
    for state in states:
        new_state = state
        while True:
            i = random.randint(0, 4)
            j = random.randint(0, 4)
            if new_state.map[i][j] == 1:
                new_state.flip(i, j)
                break
        while True:
            k = random.randint(0, 4)
            if new_state.map[i][k] == 0:
                new_state.flip(i, k)
                break
        mutated_states.append(new_state)
    return mutated_states

# Genetic algorithm
def genetic_algorithm(states):
    # Implements the genetic algorithm
    while True:
        selected = selection(states)
        crossed = crossover(selected)
        mutated = mutation(crossed)
        for state in mutated:
            if state.get_fitness() == 0:
                return state
        states = mutated

if __name__ == '__main__':
    start = time.time()

    # Generating initial states
    states = [Board(5) for _ in range(8)]

    # Running the genetic algorithm
    solution = genetic_algorithm(states)

    print("Running time: " + str(round((time.time() - start)) * 1000) + "ms")
    for row in solution.get_map():
        print(" ".join("-" if cell == 0 else "1" for cell in row))

    # The following code is commented out for demonstration purposes
    '''
    i = 0
    print("Original States:")
    for state in states:
        i+=1
        print(i, state.get_map())

    encoded_states = [encode(state) for state in states]
    i=0
    print("\nEncoded States:")
    for state in encoded_states:
        i+=1
        print(i, state.get_map())

    selected = selection(encoded_states)
    i = 0
    print("\nSelected States:")
    for state in selected:
        i+=1
        print(i, state.get_map())

    crossovered = crossover(selected)
    print("\nCrossovered States:")
    i=0
    for state in crossovered:
        i+=1
        print(i, state.get_map())

    mutated = mutation(crossovered)
    print("\nMutated States:")
    i=0
    for state in mutated:
        i+=1
        print(i, state.get_map())
    '''
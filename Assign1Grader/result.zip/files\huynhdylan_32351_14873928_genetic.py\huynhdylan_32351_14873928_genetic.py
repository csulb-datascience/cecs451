import random
import board
from datetime import datetime


def encodeState(board_input: board):
    """
    Get board state and place queen's location into a string.  Index = row, value = column
    :param board_input: Input board parameter
    :return: Board state encoded into a string
    """
    state = ""
    for i in range(len(board_input.get_map())):
        for j in range(len(board_input.get_map()[0])):
            if board_input.get_map()[i][j] == 1:
                state += str(j)

    return state


def boardPrint(board_input: board):
    """
    Converts the board object instance variable map (2d list) into printing terminal format
    :param board_input: Input board parameter
    :return: None
    """
    for i in range(len(board_input.get_map())):
        printString = ""
        for j in range(len(board_input.get_map()[0])):
            if board_input.get_map()[i][j] == 0:
                # Not sure if the grader care if there is a space at the end of the string, so I made this if
                # statement just in case
                if j == len(board_input.get_map()) - 1:
                    printString += "-"
                else:
                    printString += "- "
            else:
                # Not sure if the grader care if there is a space at the end of the string, so I made this if
                # statement just in case
                if j == len(board_input.get_map()) - 1:
                    printString += str(board_input.get_map()[i][j])
                else:
                    printString += str(board_input.get_map()[i][j]) + " "
        print(printString)


def selection(populationInput, n):
    """
    Calculates the board state's fitness and turn them into a percentage/probability.  Using these probabilities select
    the state that would survive and move on to the cross-over function
    :param populationInput: The 8 board state population
    :param n: The size of the board, since the assignment is the 5-queens problem.  n=5, meaning 5 queens
    :return: A tuple containing the new population board state and a boolean if a solution was found
    """
    solutionFound = False
    # Calculated maxFitness by doing nc2 (n choose 2)
    maxFitness = (n * (n-1))/2
    total = 0
    percentageList = []
    newPopulation = []

    for i in range(len(populationInput)):
        state, board = populationInput[i]
        if board.get_fitness() == 0:
            solutionFound = True
            return populationInput, solutionFound
        total += (maxFitness - board.get_fitness())
    for i in range(len(populationInput)):
        state, board = populationInput[i]
        if i == 0:
            percentageList.append((maxFitness - board.get_fitness())/total)
        else:
            percentageList.append(percentageList[i-1] + (maxFitness - board.get_fitness())/total)

    for i in range(len(populationInput)):
        randomSelection = random.random()
        index = 0
        while randomSelection > percentageList[index]:
            index += 1
        originalState, originalBoard = populationInput[i]
        selectedState = populationInput[index][0]
        for j in range(len(originalState)):
            # Flip the original board state
            originalBoard.flip(j, int(originalState[j]))
            # Flip the original board to the selected state configuration
            originalBoard.flip(j, int(selectedState[j]))
        # Append the original board (now with the selected state configuration)
        newPopulation.append((selectedState, originalBoard))

    return newPopulation, solutionFound

def crossOver(populationInput, solutionFound):
    """
    Crossover the board objects using a random pivot point
    :param populationInput: The 8 board state population
    :param solutionFound: If True, return the initial population before cross over
    :return: A tuple containing the new population board state and a boolean if a solution was found
    """
    # If solutionFound = True, return the population before cross over and solutionFound
    if solutionFound:
        return populationInput, solutionFound
    newPopulation = []
    for i in range(1, len(populationInput), 2):
        state1, board1 = populationInput[i - 1]
        state2, board2 = populationInput[i]
        randomPivot = random.randint(0, len(state1) - 1)

        newState1 = state1[:randomPivot] + state2[randomPivot:]
        newState2 = state2[:randomPivot] + state1[randomPivot:]

        for j in range(len(newState1)):
            # Flip the original board state
            board1.flip(j, int(state1[j]))
            board2.flip(j, int(state2[j]))

            # Flip the board to the new string encoding
            board1.flip(j, int(newState1[j]))
            board2.flip(j, int(newState2[j]))

        newPopulation.append((newState1, board1))
        newPopulation.append((newState2, board2))

    return newPopulation, solutionFound


def mutation(populationInput, solutionFound):
    """
    Randomly select board's row/column and change value
    :param populationInput: The 8 board state population
    :param solutionFound: If True, return the initial population before mutation
    :return: New population after mutation
    """
    # If solution is found, return population before mutation
    if solutionFound:
        return populationInput
    newPopulation = []
    mutationRate = 0.3
    for i in range(len(populationInput)):
        mutationNum = random.random()
        state, board = populationInput[i]
        if mutationNum < mutationRate:
            mutationIndex = random.randint(0, (len(state) - 1))
            mutationValue = random.randint(0, (len(state) - 1))
            newState = state[:mutationIndex] + str(mutationValue) + state[mutationIndex + 1:]
            for j in range(len(state)):
                # Flip the original board state
                board.flip(j, int(state[j]))

                # Flip the board to the new string encoding
                board.flip(j, int(newState[j]))

            newPopulation.append((newState, board))
        else:
            newPopulation.append((state, board))

    return newPopulation


def geneticAlgorithm(populationInput, n):
    """
    Genetic search algorithm.  This algorithm calls the selection, crossover, and mutation function.  Repeats
    infinitely until a board with the solution is reached
    :param populationInput: The 8 board state population
    :param n: The size of the board, since the assignment is the 5-queens problem.  n=5, meaning 5 queens
    :return: The board object that has the solution
    """
    newPopulation = populationInput
    while True:
        newPopulation, solutionFound = selection(newPopulation, n)
        newPopulation,solutionFound = crossOver(newPopulation, solutionFound)
        newPopulation = mutation(newPopulation, solutionFound)

        for j in range(len(newPopulation)):
            newState, newBoard = newPopulation[j]
            if newBoard.get_fitness() == 0:
                return newBoard


if __name__ == '__main__':
    startTime = datetime.now()
    population = []
    # Construct 8 distinct states
    for i in range(8):
        boardInput = board.Board(5)
        currentState = encodeState(boardInput)
        population.append((currentState, boardInput))

    solution = geneticAlgorithm(population, 5)
    endTime = datetime.now()
    timeDifference = (endTime - startTime).total_seconds() * 10 ** 3
    print(f"Running time:{timeDifference: .2f}ms")
    boardPrint(solution)


#The pseduocode from geeksforgeeks website and the textbook was used to finish the code
import time
from board import Board

def hill_climbing_algorithm(board_class_function,beginning_point ):
    starting_point = beginning_point
    for _ in range(40): #must make new board states by allowing the queens to move
        queens = create_more_queens(starting_point)
        optimal_queen = max(queens, key = board_class_function) #need to ensure best fitness
        if board_class_function(optimal_queen) <= board_class_function(starting_point):
            return starting_point
        #compare the state of fitness to ensure the optimal state
        else:
            starting_point = optimal_queen
            
def create_more_queens(board_class_function):
    #created a new board state intialization to capture queens
    queens = [] 
    
    #mus iterate new list for queens
    queens_arranged = []
    
    maximum_queen_count = len(board_class_function.get_map())
    #arrange values mbased on the matrixes
    for i in range(maximum_queen_count): 
        for j in range(maximum_queen_count):
            #locate a queen on baord
            if board_class_function.get_map()[i][j] == 1: 
                #locate a queen on baord
                for k in range(maximum_queen_count):
                    if k != maximum_queen_count:
                        #copied image of board to move the queens
                        for x in board_class_function.get_map():
                            queens_arranged.append(x.copy())
                        #no queens gets a 0
                        queens_arranged[i][j] = 0
                        #present qqueen gets a 1
                        queens_arranged[k][j] = 1
                        
                        queens.append(Board(maximum_queen_count)) #new board to the state
    return queens

if __name__ == '__main__':
    most_optimal_result = -float('inf') #initialiation 
    for _ in range(40): #record time
        hill_algorithm_start = time.time()
        run = Board(5) #create state board with 5 queens
        optimal_result = hill_climbing_algorithm(Board.get_fitness, run)# use algorithm
        attack_pairs = Board.get_fitness(optimal_result) #calculatr attacking pairs to find
        #optimal solution
        if attack_pairs > most_optimal_result: #compare results for most optimal results
            lowest_attack_pairs = attack_pairs
            final = optimal_result
        #make sure to check for total time 
        #calculate time for output
        hill_algorithm_end = int(time.time() - hill_algorithm_start) 
        hill_algorithm_ms = hill_algorithm_end * 1000
    #output format as indicated
    print('Running time: '+ str(hill_algorithm_ms) +'ms' ) 
    for x in final.get_map():
        output = ''
        for y in x:
            if y == 0:
                output += '- '
            else:
                output += '1 '
        print(output)

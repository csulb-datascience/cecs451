from random import choice, randint, random,sample
import time
from board import Board
population = []
start_time = time.time()

# Initialize the population
def generatePopulation():
    global population
    population = [Board(5) for _ in range(8)]

# Select two distinct parents from the global population
def selectParents():
    global population
    parent1, parent2 = sample(population, 2)

    # Compare the fitness of the two parents
    if parent1.get_fitness() < parent2.get_fitness():
        return parent1, parent2
    else:
        return parent2, parent1
# Perform crossover on two parents selected from the global population
def crossOver():
    parent1, parent2 = selectParents()
    point = randint(0, 4)
    child1= Board(5)
    child2 = Board(5)

    for i in range(5):
        for j in range(5):
            if i < point:
                child1.map[i][j] = parent1.map[i][j]
                child2.map[i][j] =  parent2.map[i][j]
            else:
                child1.map[i][j] = parent2.map[i][j]
                child2.map[i][j]   = parent1.map[i][j]

    return child1, child2

# Mutate a child from the crossover operation
def mutate():
    child1, child2 = crossOver()
    for child in [child1, child2]:
        for i in range(5):
            if random() < 0.3:
                new_row = randint(0, 5 - 1)
                child.map[i] = [0] * 5 
                child.map[i][new_row] = 1  # Place the queen in new r
    return child1, child2

# genetic loop
def geneticAlgorithm():
    generatePopulation(); 
    
    for i in range(50000):
        newPopulation = []

        while len(newPopulation) < 8:
            child1, child2 = mutate()
            newPopulation.extend([child1, child2])
        global population
        population = newPopulation 

        bestFitness = min(board.get_fitness() for board in population)
        
        if bestFitness == 0: 
       #     print("Solution ")
            break
    BestBoard = min(population, key=lambda x: x.get_fitness())
    return BestBoard

# print 
def print_solution(board):
    for row in board.get_map():
        print(' '.join(['1' if cell == 1 else '-' for cell in row]))
# Run the genetic algorithm
BestBoard = geneticAlgorithm()
end_time = time.time()
totalRunning = (end_time - start_time) * 1000
totalRunning =round(totalRunning, 2)
print(f"Running time: {totalRunning}ms")
print_solution(BestBoard)

import time
from board import Board
def hill (board):
    goodBoard= board
    goodFitness= goodBoard. get_fitness()
    
    for i in range(50):
        currentBoard = Board(5)
        #print(currentBoard.get_map())
        while True: 
            nextBoard = None
            bestFitness = currentBoard.get_fitness()
             ##print(best_fitness)
            for neighborStage in Neighbor(currentBoard):
             #print(neighborStage.get_map())
             neighbor_board = Board(5)
             neighbor_board.map = neighborStage
             if neighborStage.get_fitness() <  bestFitness:
                nextBoard     = neighborStage
                bestFitness = neighborStage.get_fitness()
            if nextBoard is None or bestFitness >= currentBoard.get_fitness():
                break
            currentBoard = nextBoard
        if currentBoard.get_fitness () < goodFitness:
            goodBoard =  currentBoard
            goodFitness =currentBoard.get_fitness()

    return goodBoard
            
def Neighbor(board):
    neighbor = []
    for i in range(5): 
        current_queen_pos = board.map[i].index(1)  

        for j in range(5):  
            if j != current_queen_pos:  
                newBoard = Board(5)
                newBoard.map = [row[:] for row in board.map]  
                newBoard.map[i][current_queen_pos] = 0 
                newBoard.map[i][j] = 1  
                neighbor.append(newBoard)
                
    return neighbor
def print_solution(board):
    for row in board.get_map():
        print(' '.join(['1' if cell == 1 else '-' for cell in row]))
# Run the hill algo
start_time = time.time()
Startboard = Board(5)
solutionBoard = hill(Startboard)
end_time = time.time()
totalRunning = (end_time - start_time) * 1000
totalRunning =round(totalRunning, 2)
print(f"Running time: {totalRunning}ms")
print_solution(solutionBoard)
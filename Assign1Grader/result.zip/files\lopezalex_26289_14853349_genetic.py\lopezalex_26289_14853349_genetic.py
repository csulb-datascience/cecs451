import math
import random
import sys
import board
import time
import heapq

def printMap(bd):
    for line in bd.get_map():
        # print("[", end="")
        for char in line:
            if char == 0:
                print(end="- ")
            else:
                print(char, end=" ")
        print()

# create map from gene
# return 2d array
def decode(s):
    # print(f"Gene to decode:{s}")
    map = [[0 for j in range(len(s))] for k in range(len(s))]
    for i in range(len(s)):
        map[i][int(s[i])] = 1
    return map

# create the gene of map
# return string that represents map
def encode(map):
    s = ""
    for line in map:
        for i in range(len(line)):
            if line[i] == 1:
                s += str(i)
                break
    return s

# input: minheap of tuples (fitness, board genes) and total sum of fitness
# output: 2-tup of strings (randomly selected parents)
#   randomly selects the 2 parents of next generation (better fitness=better chance)
def selection(state_heap, fit_sum):
    # print(f"STATES heap: {state_heap}")
    parents = []
    runs = len(state_heap)
    for i in range(runs):
        rand = random.randint(0, fit_sum-1) # random integer to avoid rounding issues with float

        fit_prob, temp_brd = heapq.heappop(state_heap)
        sel_prob = fit_sum - fit_prob       # selection probability (% chance = 1 - sel_prob/fit_sum)

        if i == 0: 
            first = temp_brd # takes note of first (most fit) board/map

        if len(parents) < 2 and (rand < sel_prob or i == runs-1): # will always add the last child
            parents.append(temp_brd)

    if len(parents) < 2 and first not in parents:
        parents.append(first) # adds the most fit map if one is missing
        # print("parent 2 not found", len(parents))

    return parents[0], parents[1]

# input: 2 strings (encoded genes of boards)
# output: 2 strings
#   creates 2 children from 2 parents; randomly spliced
def crossover(s1, s2):
    cross_point = random.randint(0,len(s1)-1) # get random idx to cross

    temp = s1

    s1 = s1[0:cross_point] + s2[cross_point:len(s2)]
    s2 = s2[0:cross_point] + temp[cross_point:len(temp)]

    return s1, s2 # return encoded strings

# input: string (encoded gene of board)
# output: mutated string
def mutation(s):
    MUTATIION_RATE = .20 # each row has 20% of mutating
    for i in range(len(s)):
        mutate = random.random() # random float between 0 and 1
        if mutate < MUTATIION_RATE:
            new_position = random.randint(0,len(s)-1) # inclusive range
            s = s[0:i] + str(new_position) + s[i+1:len(s)]
    return s #return mutated gene since python passes by value

def geneticSearch(bd):
    TARGET_TIME = 100 # in seconds
    # s = time.time() # starting timer
    elapsed_time = 0
    # generations = 0

    NUM_OF_STATES = 8 # must be even number
    states = [] # minheap to keep track of the most fit children
    boards = [] # direct access to all boards
    fit_sum = 0 # sum of all fitness values
    
    for i in range(NUM_OF_STATES):
        boards.append(board.Board(bd.n_queen))# initialize 8 different random board states
        fitness = boards[i].get_fitness()
        if fitness == 0:
            bd.map = boards[i].map
            # print("found1")
            return
        fit_sum += fitness
        heapq.heappush(states, (fitness, encode(boards[i].map))) # add boards to states minheap
    
    while elapsed_time < TARGET_TIME:
        # generations += 1
        parent1, parent2 = selection(states, fit_sum)
        fit_sum = 0
        for j in range(0,NUM_OF_STATES,2):
            children = crossover(parent1, parent2) # 2 tuple of newly created genes 
            for k in range(len(children)):      # go through each child from the new tuple

                mutated_gene = mutation(children[k])

                boards[j+k].map = decode(mutated_gene) # decode gene to assign map
                # printMap(boards[j+k])

                if boards[j+k].get_fitness() == 0: #check if sol found after mutation
                    bd.map = boards[j+k].map
                    return

                heapq.heappush(states, (boards[j+k].get_fitness(), encode(boards[j+k].map))) # load up states for selection
                fit_sum += boards[j+k].get_fitness()  #keep track of new fitness totals

        # elapsed_time = (time.time()-s)
        # print(generations)

    # _, bd.map = heapq.heappop(states) # at least get most fit child
    # print(f"ERROR:\n\tSolution Not Found within elapsed time: {elapsed_time:.0f}s\n")

def main(n):
    # random.seed(5) # set seed
    brd = board.Board(n)

    start_time = time.time()
    geneticSearch(brd)
    duration =  (time.time() - start_time) * 1000 # in ms

    print(f"Running time: {math.ceil(duration)}ms")
    printMap(brd)

if __name__ == '__main__':
    main(5)
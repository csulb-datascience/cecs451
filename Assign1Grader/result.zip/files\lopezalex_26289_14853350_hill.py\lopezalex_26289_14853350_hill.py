import math
import sys
import board
import time
import heapq

def printMap(bd):
    for line in bd.get_map():
        # print("[", end="")
        for char in line:
            if char == 0:
                print(end="- ")
            else:
                print(char, end=" ")
        print()

def randomReset(bd):
    bd.__init__(bd.n_queen)

def hillClimbSearch(bd):
    # count = 0
    while bd.get_fitness() > 0:
        randomReset(bd) # reset the board if every row visited and no solution found

        # # # Diagnostics
        # count += 1
        # printMap(bd)
        # print()

        for row in range(len(bd.get_map())):
            permutations = [] # minheap for each row
            for col in range(len(bd.get_map())):
                permu = [0] * len(bd.map[0]) # a single permutation
                permu[col] = 1
                bd.map[row] = permu # modify current row 
                heapq.heappush(permutations, (bd.get_fitness(),permu)) # have lowest fitness at top of heap

            fitness, bd.map[row] = heapq.heappop(permutations) # unpack and replace row with best fitness 

    # print(f"Iterations before solution found: {count}")       

def main(n):
    # board.random.seed(5) # set seed
    brd = board.Board(n)

    # print("fitness Before:",brd.get_fitness())
    # printMap(brd)

    start_time = time.time()
    hillClimbSearch(brd)
    duration =  (time.time() - start_time) * 1000 # in ms

    print(f"Running time: {math.ceil(duration)}ms")
    # print("fitness After:",brd.get_fitness())
    printMap(brd)

if __name__ == '__main__':
    main(5)
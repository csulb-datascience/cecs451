# Alexander Ly 027744520
# CECS 451 Sec 01
# Assignment 2 - Local Search
# February 12, 2024

from board import Board
import time

# implement hill climbing algorithm
def hill_climbing(problem):
    # start while until we get fitness of 0 
    while True:
        # set up our current fitness so it gets updated with each time it iterates and changes
        current = problem.get_fitness()
        # return our board when we reach a fitness of 0
        if current == 0:
            return problem
        # set up boolean to indicate if we found better move through iterations
        better_move = False
        # iterate through the rows       
        for i in range(problem.n_queen):
            # set up variable to store coords of better move 
            neighbor = None
            # iterate through column
            for j in range(problem.n_queen):
                # if position is not queen
                if problem.get_map()[i][j] == 0:
                    # flip it to become a queen
                    problem.flip(i, j)
                    # get fitness of that position
                    neighbor_value = problem.get_fitness()
                    # if fitnes is less than the current
                    if neighbor_value < current:
                        # set neighbor variable to the coords of the lower fitness value
                        neighbor = (i, j)
                        # change our current value to equal our neighbor 
                        current = neighbor_value
                        # flip back the coords to 0 and not queen
                    problem.flip(i, j)
            
            # if our neighbor value was less than current
            if neighbor is not None:
                # swap positions to the better fitness move
                problem.flip(neighbor[0], neighbor[1])
                # set better move to true to break current loop and move to next iteration
                better_move = True
                break

        # if iterate through all rows and no better move, random restart 
        if not better_move:
            problem = random_restart(problem)

# implement random restart function
def random_restart(problem):
    # return a brand new board
    return Board(problem.n_queen)

# main 
if __name__ == '__main__':
    # calculate start time
    start = time.time()
    # set our board to be 5x5
    test = Board(5)
    # run our hill climb function on the board
    run = hill_climbing(test)
    # calculate end time of code
    end = time.time()
    # calculate final time and multiply by 1000 for ms
    final_time = end-start 
    final_time = final_time * 1000
    rounded_final_time = round(final_time)
    # output
    print("Running time: ", rounded_final_time, "ms")
    for row in run.get_map():
        print(" ".join(['-' if dash == 0 else '1' for dash in row]))
import time
import random
from board import Board

'''
8 distinct states

3 fundamental operations:
	selection,
	crossover,
	mutation
'''

def crossover(parent1_string, parent2_string):
	'''
	Performs crossover operation to create a child from two parents.

	Args:
		parent1_string: String representation of the first parent.
		parent2_string: String representation of the second parent

	Returns:
		Child board generated through crossover.
	'''
	# Perform crossover on Board objects
	n = len(parent1_string)
	crossover_point = random.randint(0, n - 1)
	child_string = parent1_string[:crossover_point] + parent2_string[crossover_point:]

	# Return the crossover child_string
	return child_string

def mutate(child_string, mutation_rate):
	'''
	Performs mutation operation on a child with a given mutation rate.

	Args:
		child_string: String representation of the child.
		mutation_rate: Probability of mutation for each gene.

	Returns:
		Mutated child board as a string
	'''
	# Convert child string back to Board object
	child_list = list(child_string)

	# Perform mutation on Board object using the flip function
	for i in range(len(child_list)):
		# Apply mutation with the given probability
		if random.random() < mutation_rate:
			# Mutate 1 character to a new number from 1 to 5 then break the for loop
			new_value = random.randint(1, 5)
			child_list[i] = str(new_value)
			

	mutated_child_string = ''.join(child_list)
	# Retrun the child_board as a string
	return mutated_child_string

def selection(population):
	'''
	Performs selection operation to generate a new board.

	Args:
		population: List of board instances representing the current population.
		n: number of queens

	Returns:
		Board object representing the selected board as a string.
	'''
	# Decode the string representation into Board instances
	boards = [Board(len(individual)) for individual in population]

	# Calculate the fitness score for each individual in the population
	fitness_scores = [board.get_fitness() for board in boards]

	# Calculate the total fitness of the population
	total_fitness = sum(fitness_scores)

	# Generate a random value between 0 and the total fitness
	random_fitness = random.uniform(0, total_fitness)

	# Select the individual based on the random number
	cumulative_fitness = 0

	for i, individual_fitness in enumerate(fitness_scores):
		cumulative_fitness += individual_fitness
		if cumulative_fitness > random_fitness:
			return population[i]

	# This line of code below should never be reached
	return population

def encoded_states(board):
	'''
	Encode the current state of the board as a string.

	Args:
		board: An instance of the Board class representing the current state.

	Returns:
		A string representation of the board.
	'''
	# Initialize an empty string
	encoded_string = ""

	# Iterate through the board to find where the queen is placed and append the position of the queen (+1) into the empty string
	for row in board.get_map():
		if 1 in row:
			queen_column = row.index(1)

			encoded_string += str(queen_column + 1)

	return encoded_string

def genetic_algorithm(board):
	'''
	Performs the genetic algorithm to solve the n-queens problem.

	Args:
		board: An instace of the Board class representing the current state of the board.

	Returns:
		An instance of the board class representing the optimal solution.
	'''
	current_board = board

	# Get the size of the current board (using the number of queens)
	n = current_board.n_queen

	# Calculate the best possible fit (non-attacking pairs)
	best_possible_fit = (n * (n - 1)) / 2
	
	# Encode the board as a string
	current_board_string = encoded_states(board)

	# Create 8 distinct states/boards
	#population = [encoded_states(Board(board.n_queen)) for i in range(8)]

	for gen in range(1000):
		# Create 8 distinct states/boards
		population = [encoded_states(Board(board.n_queen)) for i in range(8)]

		# Perform the selection function to create a new board
		new_board_string = selection(population)
		
		# Perform the crossover function with the current board and new board
		child_board_string = crossover(current_board_string, new_board_string)

		# Perform the mutation function on the child board
		mutated_board_string = mutate(child_board_string, 0.3)

		# Decode the mutated board string to a Board object
		mutated_board = Board(len(mutated_board_string))
		mutated_board.map = [[0 if col != int(mutated_board_string[row])-1 else 1 for col in range(len(mutated_board_string))] for row in range(len(mutated_board_string))]

		# Calculate fitness for the current and mutated boards
		current_fitness = current_board.get_fitness()
		mutated_fitness = mutated_board.get_fitness()

		# Replace the current board with the mutated board if it has lower fitness
		if mutated_fitness < current_fitness:
			current_board = mutated_board
			current_board_string = mutated_board_string

		# Break for loop if best possible fitness is reached
		non_attacking_pairs = best_possible_fit - current_fitness
		if best_possible_fit == non_attacking_pairs:
			break

	return current_board

def print_board(board):
	for row in board.map:
		print(" ".join(["-" if cell == 0 else "1" for cell in row]))

def main():
	# initialize the board
	board = Board(5)


	start_time = time.time()

	#print(f"\nAttempting to find optimal solution using Genetics Algorithm\n")
	#print(f"Before: {board.get_map()}\n")
	solution = genetic_algorithm(board)

	end_time = time.time()
	runtime = (end_time - start_time) * 1000

	#print(f"Optimal solution was found probably\n")
	print(f"Running time: {runtime:.2f}ms")
	#print(solution.get_map())
	print_board(solution)


if __name__ == "__main__":
	main()
#Program Name: genetic.py
#Name: Aidan Mara
#Date 2/16/2024
#Version: 1.0

####################################
import time
import random
import math

from board import Board

####################################


######################### Start of Genetic Algorithm #########################
def genetic(b):
  ####################### Encoding Function ##################################

  #Not certain if it is ever used or is even working tbh just want speed >:D
  def getEncoding(Board):
    #make an empty list, could do string,but ran into some problems decoding it
    encoding = list()

    #note: I also tried just splicing the board maps,
    #but the order in the list would change randomly

    for i in range(len(Board.map)):
      for j in range(len(Board.map[0])):
        if Board.map[i][j] == 1:
          #add the column to our encoding
          encoding.append(j)
          #assuming only one queen per row, thus we can jump to the next row
          #once we find a queen
          continue

    #return the encoding
    return encoding

  ############################################################################

  ########################Decoding function###################################

  def decodeEncoding(Board, encoding):
    #go through each row setting only our encoded queens to 1 and all others to 0
    for i in range(len(Board.map)):
      for j in range(len(Board.map[0])):
        if encoding[i] == j:
          Board.map[i][j] = 1
        else:
          Board.map[i][j] = 0

  ############################################################################

  ############################## Initialization ##############################
  #Time Stamp for running time calculation at the end.
  initTS = time.time()

  #Since I take a board as a parameter:
  #Size of board
  size = len(b.map)

  #Since we are using the opposite to measure the score:
  #We subtract the max score possible (n choose 2) from the fitness score.
  maxScore = (size * (size - 1) / 2)

  #Initializing the initial 8 distinct states
  initialStates = []
  initSet = set()

  #Using a set to make sure each state has a unique map
  #While loop to make sure we have 8 distinct states
  while len(initialStates) < 8:

    #Generate a random board if the set has that board it will ignore it
    temp = Board(size)

    #Have to cast the map 2d list as a string bc list of list not hashable
    if str(temp.map) not in initSet:

      #Add to our set and add that object to our list
      initSet.add(str(temp.map))
      initialStates.append(temp)
  ############################################################################

  ############################## Main Loop ###################################
  #The loop will run until the score is equal to the max score or no attacking queens
  while maxScore not in list(
      map(lambda x: maxScore - x.get_fitness(), initialStates)):

    ############################# SELECTION #################################

    #Fitness is a list of the scores for each state
    #We subtract from max score so we can use weights to choose parents
    fitness = list(map(lambda x: maxScore - x.get_fitness(), initialStates))

    #Use total as the divisor to get the weights
    total = sum(fitness)

    #Get the weights of each parent by dividing the fitness by the total
    weights = list(map(lambda x: x / total, fitness))

    #Choose parents by choosing randomly, but weighing better candidates more
    parents = random.choices(initialStates, weights, k=8)

    ########################## END OF SELECTION ##############################

    ############################# CROSSOVER #################################

    for i in range(0, len(parents), 2):
      #Get the encodings of the parents of each pair
      parentEncodings = [
          list(getEncoding(parents[i])),
          list(getEncoding(parents[i + 1]))
      ]

      #Generate a random spot of the encoding to cut
      sliceIndex = random.randint(1, len(parentEncodings[0]) - 1)

      #Cut the encoding at the random spot and crossover
      temp = parentEncodings[0][sliceIndex:]
      parentEncodings[0][sliceIndex:] = parentEncodings[1][sliceIndex:]
      parentEncodings[1][sliceIndex:] = temp

      ########################## END OF CROSSOVER ##############################

      ############################# MUTATION #################################

      #For each child choose a gene at random and randomize that
      parentEncodings[0][random.randint(0,
                                        len(parentEncodings[0]) -
                                        1)] = random.randint(
                                            0,
                                            len(parentEncodings[0]) - 1)

      parentEncodings[1][random.randint(0,
                                        len(parentEncodings[0]) -
                                        1)] = random.randint(
                                            0,
                                            len(parentEncodings[0]) - 1)

      decodeEncoding(parents[i], parentEncodings[0])
      decodeEncoding(parents[i + 1], parentEncodings[1])

  ########################## END OF MUTATION ##############################

  ########################## END OF MAIN LOOP ##############################

  ######################### WRAP UP #########################################
  #Here we have reached a state where one of the states has the max score, so we print it out.
  index = list(map(lambda x: maxScore - x.get_fitness(),
                   initialStates)).index(maxScore)

  solution = initialStates[index]

  #Run time in ms
  print('Running time: ', int((time.time() - initTS) * 1000), 'ms')

  #Print the solution in the necessary format.
  for row in solution.map:
    s = ''
    for column in range(len(row)):
      if row[column] == 0:
        s += ' - '
      else:
        s += ' 1 '
    print(s)


##############################################################################
def main():
  test = Board(5)
  genetic(test)


main()

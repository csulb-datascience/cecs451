import random
import time
from board import Board


def hill_climbing():
    size = 5
    restarts = 10
    start = time.time()

    best_state = None
    best_fitness = float('inf')

    for _ in range(restarts):
        # Initialize the Board object for each restart
        board = Board(size)
        current_state = board.get_map()
        current_fitness = board.get_fitness()

        while current_fitness != 0:
            for i in range(size):
                for j in range(size):
                    if current_state[i][j] == 0:
                        # Flip the cell value from 0 to 1
                        board.flip(i, j)
                        # Calculate the fitness value after flipping
                        new_fitness = board.get_fitness()

                        # Check if the new fitness is lower than the best fitness
                        if new_fitness < best_fitness:
                            # Update the best state and best fitness
                            best_state = board.get_map()
                            best_fitness = new_fitness

                        # Flip the cell back to its original value
                        board.flip(i, j)

            # If the current state's fitness is the same as the best fitness, terminate the loop
            if current_fitness == best_fitness:
                break

            # Update the current state and fitness for the next iteration
            current_state = best_state
            current_fitness = best_fitness

    end = time.time()
    execution_time_ms = round((end - start) * 1000, 1)
    print("Execution time:", execution_time_ms, "ms")

    return best_state, best_fitness


if __name__ == "__main__":
    best_state, best_fitness = hill_climbing()
    # print("Best State:")
    for row in best_state:
        print(" ".join(map(lambda x: '-' if x == 0 else '1', row)))


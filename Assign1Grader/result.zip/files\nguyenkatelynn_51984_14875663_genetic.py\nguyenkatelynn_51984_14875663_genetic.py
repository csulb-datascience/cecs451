import board
import time
import random
import math

# initialize queen board
def initialize_board(state):
    state.map = []
    for i in range(state.n_queen):
        row = [0] * state.n_queen
        state.map.append(row)

# randomly placing queens on the board
# helper function for set_board
def queen_pos(state):
    queen_positions = []
    for col in range(state.n_queen):
        row = random.randint(0, state.n_queen - 1)
        state.map[row][col] = 1
        queen_positions.append(state.n_queen - row)
    return queen_positions

def set_board(state):
    initialize_board(state)
    queen_positions = queen_pos(state)
    return queen_positions


def queen_fitness(state):
    fit = 0
    for i in range(state.n_queen):
        for j in range(state.n_queen):
            if state.get_map()[j][i] == 1:
                for k in range(1, state.n_queen - i):
                    if state.get_map()[j][i + k] == 1:
                        fit += 1
                    if j - k >= 0 and state.get_map()[j - k][i + k] == 1:
                        fit += 1
                    if j + k < state.n_queen and state.get_map()[j + k][i + k] == 1:
                        fit += 1
    return fit

# converts array object to board, and converting to 0's
def convert_to_board(new_arr):
    queen_board = board.Board(5)
    for i in range(queen_board.n_queen):
        for j in range(queen_board.n_queen):
            if queen_board.get_map()[i][j] == 1:
                queen_board.flip(i, j)
    for i, j in enumerate(new_arr):
        queen_board.get_map()[len(new_arr) - j][i] = 1
    return queen_board

# selection for crossover and mutation
def selection(arr):
    idx = []
    for _ in range(len(arr)):
        rand = random.random()
        match rand:
            case _ if rand <= arr[0]:
                idx.append(0)
            case _ if rand <= sum(arr[:2]):
                idx.append(1)
            case _ if rand <= sum(arr[:3]):
                idx.append(2)
            case _ if rand <= sum(arr[:4]):
                idx.append(3)
            case _ if rand <= sum(arr[:5]):
                idx.append(4)
            case _ if rand <= sum(arr[:6]):
                idx.append(5)
            case _ if rand <= sum(arr[:7]):
                idx.append(6)
            case _:
                idx.append(7)
    return idx


def crossover(states):
    board_size = convert_to_board(states[0]).n_queen
    rand_idx = []
    for _ in range(len(states) // 2):
        rand_idx.append(random.randint(0, board_size - 1))
    a = 0
    i = 0
    while i < len(states):
        idx = rand_idx[a]
        tmp = states[i][idx:]
        states[i] = states[i][:idx] + states[i + 1][idx:]
        states[i + 1] = states[i + 1][:idx] + tmp
        a += 1
        i += 2

    return states


# performs mutations on random indices
def mutation(states):
    board_size = convert_to_board(states[0]).n_queen 
    rand_idx = []
    for _ in range(len(states)):
        rand_idx.append(random.randint(0, board_size - 1))
    for i in range(len(rand_idx)):
        rand_num = random.randint(1, board_size)
        states[i][rand_idx[i]] = rand_num
    return states


def genetic(states):
    new_fitness = []
    best_prob = []
    for i in range(len(states)):
        state = convert_to_board(states[i])
        a = math.comb(state.n_queen, 2) - queen_fitness(state)
        new_fitness.append(a)

    for j in range(len(states)):
        best_prob.append(round(new_fitness[j] / sum(new_fitness), 2))

    idx = selection(best_prob)

    new_states = [0] * len(states)
    for k in range(len(states)):
        new_idx = idx[k]
        new_states[k] = states[new_idx]

    new_states = crossover(new_states)
    diff_states = mutation(new_states)

    new_fitness = -1
    best_board = None
    # iterates over diff states to convert to board
    # then calculates fitness of board -> searching for highest fitness
    for sol in diff_states:
        new_board = convert_to_board(sol)
        fitness = queen_fitness(new_board)
        if fitness == 0:
            return new_board
        elif fitness > new_fitness:
            new_fitness = fitness
            best_board = new_board

    return best_board

def display_board_pos(board):
    for row in board.map:
        for i in row:
            if i == 1:
                print("1", end=" ")
            else:
                print("-", end=" ")
        print()


if __name__ == "__main__":
    start = time.time()
    while True:
        states = []
        i = 0
        while i < 8:
            queen_board = board.Board(5)
            state = set_board(queen_board)
            states.append(state)
            i += 1
        solution = genetic(states)
        if queen_fitness(solution) == 0:
            end = time.time()
            print("Running time:", round((end - start) * 1000), "ms")
            display_board_pos(solution)
            break






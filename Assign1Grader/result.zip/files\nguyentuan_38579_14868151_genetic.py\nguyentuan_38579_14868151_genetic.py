# Tuan Nguyen
# Assignment_2    N_Queens problem
# CECS 451 Professor Moon
# Algorithm citation:
#ChatGPT. (2024, February 12). Re: Genetic Algorithm for N-Queens Problem [Personal Communication].

import random
import time
from copy import deepcopy
from board import Board

num_of_Queens = 5


# randomly selects 2 states
def selection(states):
    random_state1 = states[random.randint(0, 7)]
    random_state2 = states[random.randint(0, 7)]

    return [random_state1, random_state2]


# split and combine
def crossover(parent1_board, parent2_board):
    # a new board for the child
    child_board = Board(num_of_Queens)
    # random split point starting at index 1 instead of 0 to avoid splitting at beginning
    randomly_split = random.randint(1, parent1_board.n_queen - 1)
    # parents board at split location
    parent1_split_point = deepcopy(parent1_board.map[:randomly_split])
    parent2_split_point = deepcopy(parent2_board.map[randomly_split:])
    # combine the parents split point into the child board
    child_board.map = parent1_split_point + parent2_split_point
    return child_board


def mutation(board):
    row = random.randint(0, board.n_queen - 1)
    col = random.randint(0, board.n_queen - 1)

    # Place queen in the mutated position
    board.map[row][col] = 1


def genetic_algorithm(state_size, size):

    while True:
        # get 8 distinct state of chess board with 5 queens each
        eight_distinct_states = []
        for i in range(state_size):
            eight_distinct_states.append(Board(num_of_Queens))
        # iterate through the set size to find optimal solution
        for i in range(size):
            # Selection
            selected_states = selection(eight_distinct_states)

            # Crossover
            offspring = [crossover(selected_states[0], selected_states[1])]

            # Mutation
            for child in offspring:
                if random.random() < 0.1:
                    mutation(child)

            # Check for solution
            solution = sorted(eight_distinct_states + offspring, key=lambda x: x.get_fitness())[:state_size]
            if solution[0].get_fitness() == 0:
                return solution[0].get_map()


if __name__ == '__main__':
    start_time = time.time()
    optimal_solution = genetic_algorithm(state_size=8, size=100)
    end_time = time.time()

    total_time = (end_time - start_time) * 1000
    print(f"Running time: {round(total_time)}ms")
    for row in optimal_solution:
        print(" ".join(map(lambda x: "-" if x == 0 else "1", row)))



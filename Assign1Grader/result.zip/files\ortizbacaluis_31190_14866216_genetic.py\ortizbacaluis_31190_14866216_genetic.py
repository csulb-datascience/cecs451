import board, time, random



def fitness(chess) -> int:
    return int(sum(chess))

def fit(num):
    return (num * (num-1))// 2

def get_parents(population):
    return random.sample(population,2)

def crossover(parent1:board.Board,parent2:board.Board): 
    # r1 = random.randint(0,parent1.n_queen - 1)
    r2 = random.randint(0,parent1.n_queen)
    child1 = parent1.map[:r2] + parent2.map[r2:]
    child2 = parent2.map[:r2] + parent1.map[r2:]
    return child1, child2

def mutate(child:list):
    # for i in range(len(child)):
    r = random.randint(0,len(child) - 1)
    r1 = random.randint(0,len(child) - 1)
    r3 = random.randint(0,len(child) - 1)
    child[r][r1] = child[r3][r1]
    return child

def genetic(population) -> board.Board:
    t = time.perf_counter()
    children = []
    for gen in range(1,8,2):
        parent1,parent2 = get_parents(population)    
        child1,child2 = crossover(parent1,parent2)
        child1 = mutate(child1)
        child2 = mutate(child2)
        children.extend([child1,child2])
    
    max_fit = fit(5)
    current_fit = 0
    for state in children:
        # for section in state:
         find_queen = find_queens(state)
         current = fitness(find_queen)
         if current  >= current_fit and current_fit <= max_fit:
             current_fit = current
             best_state = state
             
    t_end = time.perf_counter()
    return best_state, t_end - t
    
def find_queens(chessboard:list) -> list:
    get_queen = []
    for i in range(len(chessboard)):
        for j in range(len(chessboard)):
            if chessboard[i][j] == 1:
                get_queen.append(j)
    return get_queen

def print_board(chess,time):
    print(f"Running time: {time:.2f}ms")
    for i in range(len(chess)):
        for j in range(len(chess)):
            if chess[i][j] == 1:
                print("1",end=' ')
            else: print('-',end=' ')
        print()



def main():
    population = []
    for _ in range(8):
        population.append(board.Board(5))
    
    # chorm = []
    # for i in population:
        # chorm.append(find_queens(i))
    # max_fit = (population.n_queen*(population.n_queen - 1))/2
    # x = find_queens(population)
    # print(print_board(population,5))
    # print(x)
    # print(chorm)
    # p1,p2 = get_parents(population=population)
    # c1,c2 = crossover(p1,p2)
    # print(c1)
    # # print(c2)
    # print()
    # print(mutate(c1))
    print()
    answer, times = genetic(population)
    print_board(answer,times * 1000)
    
if __name__=='__main__':
    main()
import board
import random
import numpy as np
import time


def hill(chessbord:board.Board):
    min_fit = chessbord.get_fitness()
    t = time.perf_counter()
    # base case when we get the be the best solution
    if min_fit == 0:
        t_end = time.perf_counter()
        return t - t_end, chessbord
    
    # current_board = chessbord             
    while True:
        neighbor = board.Board(chessbord.n_queen)
        
        if neighbor == chessbord:
            neighbor = board.Board(chessbord.n_queen)
            
        neighbor_fit = neighbor.get_fitness()
        if neighbor_fit <= min_fit:
            # current_board = neighbor
            min_fit = neighbor_fit
        if neighbor_fit == 0:
            t_end = time.perf_counter()
            return t_end - t, neighbor
        
            


def print_board(chess:board.Board,time):
    print(f"Running time: {time:.2f}ms")
    for i in range(chess.n_queen):
        for j in range(chess.n_queen):
            if chess.map[i][j] == 1:
                print("1",end=' ')
            else: print('-',end=' ')
        print()
    
        
def main():
    test = board.Board(5)
    time_elap, chess = hill(test)
    print_board(chess,time_elap*1000)
    

if __name__ == "__main__":
    main()
import random
import time
from board import Board

# does mutation on a board
def geneticMutation(board):
    n = board.n_queen
    boardAfterMutation = Board(n)
    boardAfterMutation.map = [row[:] for row in board.map]
    row = random.randint(0, n - 1)
    col = random.randint(0, n - 1)
    boardAfterMutation.map[row] = [0] * n
    boardAfterMutation.map[row][col] = 1
    return boardAfterMutation

# does crossover on a board
def geneticCrossover(boardParent1, boardParent2):
    n = boardParent1.n_queen
    boardChild1 = Board(n)
    boardChild2 = Board(n)
    crossoverPoint = n // 2
    boardChild1.map = boardParent1.map[:crossoverPoint] + boardParent2.map[crossoverPoint:]
    boardChild2.map = boardParent2.map[:crossoverPoint] + boardParent1.map[crossoverPoint:]
    return boardChild1, boardChild2

# genetic algorithm that uses the necessary operations
def geneticAlgorithm(numberOfStates, numberOfTimesToMutate, maximumNumberOfProductions):
    timeInitial = time.time()
    boardStatePopulation = [Board(5) for _ in range(numberOfStates)]
    production = 0
    while production < maximumNumberOfProductions:
        boardStatePopulation.sort(key=lambda x: x.get_fitness())
        if boardStatePopulation[0].get_fitness() == 0:
            break
        newBoardStatePopulation = []
        for _ in range(numberOfStates // 2):
            boardParent1, boardParent2 = random.choices(boardStatePopulation[:numberOfStates // 2], k=2)
            boardChild1, boardChild2 = geneticCrossover(boardParent1, boardParent2)
            if random.random() < numberOfTimesToMutate:
                boardChild1 = geneticMutation(boardChild1)
            if random.random() < numberOfTimesToMutate:
                boardChild2 = geneticMutation(boardChild2)
            newBoardStatePopulation.extend([boardChild1, boardChild2])
        boardStatePopulation = newBoardStatePopulation
        production += 1
    print("Running time: {:.0f}ms".format((time.time() - timeInitial) * 1000))
    solution = boardStatePopulation[0].get_map()
    for row in solution:
        print(' '.join(['-' if cell == 0 else '1' for cell in row]))

if __name__ == "__main__":
    geneticAlgorithm(numberOfStates=8, numberOfTimesToMutate=0.1, maximumNumberOfProductions=1000)

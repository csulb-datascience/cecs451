from board import Board
import random
import sys
import time
import random # Referenced the docs for random to know things like .choices and .randint

StartTime = time.time()

def HValue(n): # I only call this once, but I made this while developing so I'mma keep it
    n=int(n)
    return float (n*(n-1))/2

def BoardToString(board): 
    answer = ''
    for row in range(board.n_queen):
        for cell in range(board.n_queen):
            if board.map[row][cell] == 1:
                answer += str(cell+1)
    return answer

def CrossOver(str1, str2):
    RandomNum = random.randint(1, len(str1)-1)
    #print("RandomNum", RandomNum)
    output1 = str1[:RandomNum] + str2[RandomNum:]
    output2 = str2[:RandomNum] + str1[RandomNum:]
    return [output1, output2]
    
def mutation(str1):
    spot = random.randint(0, len(str1)-1)
    rando = str(random.randint(1,len(str1)))
    answer = str1[:spot] + rando + str1[spot+1:]
    return answer

def StringToBoard(string):
    #begin = len(string)
    new_board = Board(begin)
    for i in range(begin):
        for j in range(begin):
            new_board.map[i][j] = 0
    for i, char in enumerate(string):
        col = int(char) - 1
        if 0 <= col < begin: 
            new_board.map[i][col] = 1
    return new_board 

#CHANGE THIS VALUE IF YOU WANT MORE QUEENS OR LESS. Board size is begin * begin
begin = 5
#begin = int(sys.argv[1])
boards = []
fitnesses = []
StringBoard = []
generation = 0
TheHvalue = HValue(begin)

for i in range(8):
    boards.append(Board(begin))
    fitnesses.append(TheHvalue-boards[i].get_fitness())
    StringBoard.append(BoardToString(boards[i]))

while generation < 100:
    #I could probably use less lists. But for the sake of this assigment that only has
    # a board size of 5. I'mma use more lists for more clarity.
    OddsOfSurvival= []
    pairs = []
    crosslist=[]
    mutationlist=[]
    donttouch=[] # So best choices don't get mutated

    # FITNESS & SELECTION #
    for i in fitnesses: #Runs 8 times
        OddsOfSurvival.append(float(i) / float(sum(fitnesses)))
    bestchance = OddsOfSurvival.index(max(OddsOfSurvival))
    
    # MAKING PAIRS #
    for i in range(8):
        index_chosen = random.choices(range(8), weights=OddsOfSurvival, k=1)[0] # A one liner to choose a random index based on the decimals
        pairs.append(StringBoard[index_chosen])
        if index_chosen == bestchance:
            donttouch.append(len(pairs)-1)

    # CROSSOVER #
    for i in range(0, len(pairs), 2):
        crosslist.append(CrossOver(pairs[i], pairs[i+1]))
    temp = []
    for i in crosslist:
        for j in i:
            temp.append(j)
    
    # MUTATION #
    for count,i in enumerate(temp):
        if count in donttouch:
            mutationlist.append(i)
        else:
            mutationlist.append(mutation(i))

    StringBoard=[]
    fitnesses=[]
    # FOR GENERATION #
    for i in range(len(mutationlist)):
        StringBoard.append(mutationlist[i])
        fitness = TheHvalue - float(StringToBoard(mutationlist[i]).get_fitness())
        fitnesses.append(fitness)
    
    generation+=1
    # FOR SUCCESS #
    if TheHvalue in fitnesses:
        EndTime = time.time()
        TotalTime = (EndTime - StartTime) * 1000
        # print(f"Running time: {TotalTime:.2f}ms") # IF YOU WANT MORE DECIMALS
        print(f"Running time: {TotalTime:.0f}ms")
        index = fitnesses.index(TheHvalue)
        for row in StringToBoard(StringBoard[index]).map:
            print(' '.join(['1' if cell == 1 else '-' for cell in row]))
        break
    
if TheHvalue not in fitnesses:
    print("No solution found in 100 generations.")

from board import Board
import heapq
import time

def hillClimbingAlgorithm() -> list[list[int]]:
    nQueens = 5
    board = Board(nQueens)
    counter = 0

    while board.get_fitness() != 0:
        map = board.get_map()
        for i, row in enumerate(map):
            for j, column in enumerate(row):
                if map[i][j] == 1:
                    nextStates = []
                    board.flip(i, j)
                    # Calculate next board states fitness score including original state
                    # There is a a scenario where the original state is the best next state.
                    # Store our next possible states in a heapq
                    for z in range(0, nQueens):
                        board.flip(i, z)
                        heapq.heappush(nextStates, (board.get_fitness(), [i, z]))
                        board.flip(i, z)
                    # Retrive next state with lowest fitness score and modify transform current state
                    nextState = heapq.heappop(nextStates)
                    pos = nextState[1]
                    board.flip(pos[0], pos[1])

        # Restart board state to if stuck in a local minimum. 
        counter += 1
        if counter > 10:
            board = Board(nQueens)
            counter = 0
    return board        

def displayBoard(map):
    for i, row in enumerate(map):
        for j, column in enumerate(row):
            if map[i][j] == 0:
                print(end="- ")
            else:
                print(end="1 ")
        print()

if __name__ == "__main__":
    start_time = time.time()
    board = hillClimbingAlgorithm()
    endTime = time.time()
    elapsedTimeMs = (endTime - start_time) * 1000
    print(f"Running time: {elapsedTimeMs:.0f}ms")
    displayBoard(board.get_map())

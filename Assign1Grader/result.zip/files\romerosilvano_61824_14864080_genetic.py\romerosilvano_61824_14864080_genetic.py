from board import Board
from random import random, randint
import time

def encodeBoardState(board: list[list[int]]) -> str:
    encodedString = ''
    for row in board:
        for cIndex, square in enumerate(row):
            if square == 1:
                encodedString += str(cIndex)
    return encodedString

def geneticAlgorithm() -> list[list[int]]:
    counter = 0
    startingStates = [Board(5) for i in range(8)]
    while True:
        # Initial states
        statesFitnessAndEncodedStr = []
        totalFitnessScore = 0

        # Calculate fitness for each state
        for board in startingStates:
            statesFitnessAndEncodedStr.append([getNonAttackingPairs(board.get_map(), board.n_queen), encodeBoardState(board.get_map())])
            totalFitnessScore += getNonAttackingPairs(board.get_map(), board.n_queen)
        #print(statesFitnessAndEncodedStr)
        # Prepare states for selection
        for i, pair in enumerate(statesFitnessAndEncodedStr):
            if i == len(statesFitnessAndEncodedStr) - 1:
                pair[0] = 1
            elif i > 0:
                pair[0] = pair[0]/totalFitnessScore + statesFitnessAndEncodedStr[i - 1][0]
            else:
                pair[0] = pair[0]/totalFitnessScore

        #print(statesFitnessAndEncodedStr)
        # Select surviving states
        nextBoardStates = []
        for i in range(8):
            survivorVal = random()
            #print(i+1, survivorVal)
            for state in statesFitnessAndEncodedStr:
                if survivorVal <= state[0]:
                    nextBoardStates.append(state)
                    break

        #Cross Over States
        operation = 0
        statesWithXOver = []
        for i in range(0, 8, 2):
            componentOne = nextBoardStates[i][1]
            componentTwo = nextBoardStates[i+1][1]
            if operation % 2 == 0:
                spliceOne = componentOne[2:]
                spliceTwo = componentTwo[2:]
                componentOne = componentOne[:2] + spliceTwo
                componentTwo = componentTwo[:2] + spliceOne
            else:
                spliceOne = componentOne[3:]
                spliceTwo = componentTwo[3:]
                componentOne = componentOne[:3] + spliceTwo
                componentTwo = componentTwo[:3] + spliceOne
            
            statesWithXOver.append(componentOne)
            statesWithXOver.append(componentTwo)
            operation += 1

        # Mutate States
        #print(statesWithXOver)
        statesWithMutation = []
        for state in statesWithXOver:
            mutationIndex = randint(0, len(state))
            if mutationIndex != len(state):
                if mutationIndex != len(state) - 1:
                    state = state[:mutationIndex] + str(randint(0, len(state) - 1)) + state[mutationIndex + 1:]
                else:
                    state = state[:mutationIndex] + str(randint(0, len(state) - 1)) 
            statesWithMutation.append(state)

        #update list of boards with new states
        for i, board in enumerate(startingStates):
            updateBoardWithNewState(board, statesWithMutation[i])

        for board in startingStates:
            if getNonAttackingPairs(board.get_map(), 5) == 10:
                #print(counter)
                return board
        counter += 1 
        #return None

def updateBoardWithNewState(board: Board, newState: str) -> None:
    map = board.get_map()
    for i, row in enumerate(map):
        newVal = newState[i]
        for j, col in enumerate(row):
            if map[i][j] == 1:
                board.flip(i, j)
            if j == int(newVal):
                board.flip(i, j)
    #print(board.get_map(), newState)



def verticalSearch(map: list[list[int]], i: int, j: int, nqueens: int):
    itemp = i - 1
    queens = 0
    while itemp >= 0:
        if map[itemp][j] == 1:
            queens += 1
            break
        itemp -= 1

    itemp = i + 1
    while itemp < nqueens:
        if map[itemp][j] == 1:
            queens += 1
            break
        itemp += 1
        #print(i, jtemp)
    #print(queens)
    return queens

def diagonalSearch(map: list[list[int]], i: int, j: int, nqueens: int) -> int:
    #print(map)
    directions = [(-1,-1), (-1, 1), (1, -1), (1,1)]
    queens = 0
    for direction in directions:
        #print(direction)
        itemp = i + direction[0]
        jtemp = j + direction[1]
        while 0 <= itemp < nqueens and 0 <= jtemp < nqueens:
            if map[itemp][jtemp] == 1:
                #print(f"{direction} : found pair ({i},{j}) with ({itemp},{jtemp})")
                queens += 1
                break
            itemp += direction[0]
            jtemp += direction[1]
    #print("QUEENS: ", queens)
    return queens

def getNonAttackingPairs(map: list[list[int]], nqueens: int) -> int:
    fit = 0
    for i in range(nqueens):
        for j in range(nqueens):
            if map[i][j] == 1:
                fit += nqueens - 1 - (verticalSearch(map, i, j, nqueens) + diagonalSearch(map, i, j, nqueens))
    return fit/2


def displayBoard(map):
    for i, row in enumerate(map):
        for j, column in enumerate(row):
            if map[i][j] == 0:
                print(end="- ")
            else:
                print(end="1 ")
        print()
# [
#     [1, 0, 0, 0, 0], 1 3
#     [0, 0, 1, 0, 0], 1 3
#     [0, 0, 0, 0, 1], 2 2
#     [0, 1, 0, 0, 0], 3 1
#     [0, 0, 0, 1, 0], 1 3
# ]

if __name__ == "__main__":
    start_time = time.time()
    board = geneticAlgorithm()
    endTime = time.time()
    elapsedTimeMs = (endTime - start_time) * 1000
    print(f"Running time: {elapsedTimeMs:.0f}ms")
    displayBoard(board.get_map())



"""
Genetic Algorithm solution to the n-queens problem (n=5).

Author: Hunter Ruebsamen
Class: CECS451
"""
from board import Board
import random
import time

def initialize_population(size : int, n : int) -> list:
    """
    Define an initial random poulation of size n. Each individual is a 'Board'
    """
    return [Board(n) for _ in range(size)]

def calc_fitness(board: Board) -> int:
    return board.get_fitness()

def roulette_selection(population : list, fitness_scores: list) -> list:
    """
    use random.choices to return a k sized population using the provided relative weights, we have to invert the
    scores first, because lowest fitness is the best
    """
    # Invert fitness scores to use them as weights for selection:
    # The lower the fitness score, the higher the selection probability.
    inverted_weights = [1.0 / (1 + score) for score in fitness_scores]  # Adding 1 to avoid division by zero
    total_weight = sum(inverted_weights)
    normalized_weights = [weight / total_weight for weight in inverted_weights]
    
    # Select two individuals based on the inverted weights
    selected = random.choices(population, weights=normalized_weights, k=2)
    return selected

def crossover(parent1 : Board, parent2 : Board, crossover_rate=0.85) -> Board:
    """
    mate the two parents to produce a single offspring, crossover chromosomes at crossover rate (def 85%)
    """
    n = parent1.n_queen
    child = Board(n)
    
    if random.random() < crossover_rate:
        # Perform crossover
        point = random.randint(1, n - 2)  # Ensure at least part of each parent is used
        for row in range(n):
            col_parent1 = parent1.map[row].index(1)
            col_parent2 = parent2.map[row].index(1)

            if row < point:
                # Child inherits from first parent
                if child.map[row][col_parent1] == 0:
                    child.flip(row, col_parent1)
                # Ensure the rest of the row is clear
                for col in range(n):
                    if col != col_parent1 and child.map[row][col] == 1:
                        child.flip(row, col)
            else:
                # child inherits from 2nd parent
                if child.map[row][col_parent2] == 0:
                    child.flip(row, col_parent2)
                # Ensure the rest of the row is clear
                for col in range(n):
                    if col != col_parent2 and child.map[row][col] == 1:
                        child.flip(row, col)
    else:
        # If crossover does not occur, randomly choose one of the parents to clone as the child
        parent_to_clone = parent1 if random.random() < 0.5 else parent2
        for row in range(n):
            col_parent = parent_to_clone.map[row].index(1)
            # Set the queen's position from the selected parent
            if child.map[row][col_parent] == 0:
                child.flip(row, col_parent)
            # Ensure the rest of the row is clear
            for j in range(n):
                if j != col_parent and child.map[row][j] == 1:
                    child.flip(row, j)

    return child

def mutate(individual: Board, mutation_rate=0.01):
    """
    mutate the given individual (Board) chroimosome by the mutation rate (default 1%)
    """
    for i in range(individual.n_queen):
        if random.random() < mutation_rate:
            # Find the current position of the queen in row i
            current_pos = individual.map[i].index(1)
            # Generate a new position for the queen in row i, different from the current one
            new_pos = random.randint(0, individual.n_queen - 1)
            while new_pos == current_pos:
                new_pos = random.randint(0, individual.n_queen - 1)
            
            # Use board.flip() to remove the queen from its current position
            individual.flip(i, current_pos)
            # And place it in the new position
            individual.flip(i, new_pos)

def genetic_algorithm(n=5):
    population_size = 8
    generations = 20000
    mutation_rate = 0.01
    crossover_rate = 0.85

    population = initialize_population(population_size, n)
    generation_count = 1

    for _ in range(generations):
        weights = [calc_fitness(board) for board in population]
        if max(weights) == 0:  # Solution found
            # print(f"break {generation_count}")
            break

        # create new population from old population usign crossover and mutation
        new_population = []
        for _ in range(len(population) // 2):
            parent1, parent2 = roulette_selection(population, weights)
            child1 = crossover(parent1, parent2, crossover_rate)
            child2 = crossover(parent2, parent1, crossover_rate)
            mutate(child1, mutation_rate)
            mutate(child2, mutation_rate)
            new_population.extend([child1, child2])

        population = new_population
        best_solution = min(population, key=calc_fitness)
        #print(calc_fitness(best_solution))
        generation_count += 1

    best_solution = min(population, key=calc_fitness)
    return best_solution, generation_count

if __name__ == '__main__':
    start_time = time.time()
    n = 5
    solution, generation_count = genetic_algorithm(n)
    end_time = time.time()
    elapsed_time = (end_time - start_time) * 1000  # Convert to milliseconds
    # print(f"Num Generations: {generation_count}")
    # print(f"Final Fitness: {solution.get_fitness()}")
    print(f"Running time: {elapsed_time:.0f}ms")
    for row in solution.map:
        print(' '.join('-' if x == 0 else '1' for x in row))
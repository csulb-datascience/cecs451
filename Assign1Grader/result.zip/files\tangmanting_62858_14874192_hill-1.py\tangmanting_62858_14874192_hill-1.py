# hill.py
import random
import time
from board import Board

def generate_neighbors(state, board):
    neighbors = []
    for col in range(board.n_queen):
        for row in range(board.n_queen):
            if state[col][row] != 1:
                neighbor = [list(row) for row in state]
                neighbor[col][row] = 1
                neighbors.append([tuple(row) for row in neighbor])

    return neighbors

def print_solution(solution):
    for row in solution:
        print(" ".join(["-" if square != 1 else "1" for square in row]))

def hill_climbing(board):
    start_time = time.time()

    current_state = board.get_map()
    current_fitness = board.get_fitness()

    while True:
        neighbors = generate_neighbors(current_state, board)
        if not neighbors:
            break
        neighbor = min(neighbors, key=lambda state: board.get_fitness())
        neighbor_fitness = board.get_fitness()

        if neighbor_fitness >= current_fitness:
            break

        current_state = neighbor
        current_fitness = neighbor_fitness

    end_time = time.time()
    running_time = int((end_time - start_time) * 1000)

    return current_state, current_fitness, running_time

if __name__ == "__main__":
    board = Board(5)
    solution, fitness, running_time = hill_climbing(board)

    print("Running Time:", running_time, "ms")
    print_solution(solution)

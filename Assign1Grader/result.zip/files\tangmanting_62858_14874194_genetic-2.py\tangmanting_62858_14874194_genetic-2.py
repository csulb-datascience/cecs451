import random
from board import Board
import time

def random_chromosome(n):
  return [random.randint(0, n - 1) for _ in range(n)]

def fitness(chromosome, board):
  fit = 0
  n = len(chromosome)

  for i in range(n):
    for j in range(i + 1, n):
      if chromosome[i] == chromosome[j] or abs(i - j) == abs(chromosome[i] - chromosome[j]):
        fit += 1

  return fit

def probability(chromosome, board):
  return 1 / (1 + fitness(chromosome, board))

def random_pick(population, probabilities):
  pp = zip(population, probabilities)
  total = sum(probabilities)
  r = random.uniform(0, total)
  upto = 0

  for chrom, prob in zip(population, probabilities):
      # Check if the accumulated probability is greater than or equal to the random value
    if upto + prob >= r:
      # Return the selected chromosome
      return chrom
    upto += prob

# Swap queen positions between two parents
def crossover(parent1, parent2):
  n = len(parent1)
  c = random.randint(1, n - 1)
  child1 = parent1[:c] + parent2[c:]
  child2 = parent2[:c] + parent1[c:]
  return child1, child2

# Mutate a chromosome by randomly flipping a queen
def mutate(chromosome, mutation_probability):
  n = len(chromosome)
  mutated_chrom = chromosome.copy()
  for i in range(n):
    if random.uniform(0, 1) < mutation_probability:
      mutated_chrom[i] = random.randint(0, n - 1)
  return mutated_chrom

def plot_solution(solution):
  n = len(solution)
  board = [["0" for _ in range(n)] for _ in range(n)]

  for i, queen_col in enumerate(solution):
    board[i][queen_col] = "1"

  for row in board:
    print(" ".join(row))

def genetic_algorithm(board, population_size, generations):
  start_time = time.time()

  population = [random_chromosome(board.n_queen) for _ in range(population_size)]
  mutation_probability = 0.1

  best_solution = None

  for generation in range(generations):
    #check the probabiity of each chromosome
    probabilities = [probability(chrom, board) for chrom in population]

    #select two parents
    selected_parents = [random_pick(population, probabilities) for _ in range(population_size // 2)]

    # check the fitness of each parent
    offspring = []
    for i in range(0, len(selected_parents), 2):
      parent1 = selected_parents[i]
      parent2 = selected_parents[i + 1]

      child1, child2 = crossover(parent1, parent2)

      child1 = mutate(child1, mutation_probability)
      child2 = mutate(child2, mutation_probability)

      offspring.extend([child1, child2])

  population = selected_parents + offspring

  current_best_solution = min(population, key=lambda x: fitness(x, board))

  if best_solution is None or fitness(current_best_solution, board) < fitness(best_solution, board):
    best_solution = current_best_solution

  end_time = time.time()
  running_time = int((end_time - start_time) * 1000)
  return best_solution, running_time

if __name__ == '__main__':
  n_queens = 5
  board = Board(n_queens)

  best_solution, running_time = genetic_algorithm(board, population_size=8, generations=100)

  print("Running Time:", running_time, "ms")
  plot_solution(best_solution)
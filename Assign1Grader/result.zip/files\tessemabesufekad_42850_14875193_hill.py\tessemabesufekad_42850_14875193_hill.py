import random
import time
from board import Board


def hill_climbing(n):
    board = Board(n)
    fitness = board.get_fitness()

    max_attempts = 1000

    while fitness > 0:
        row = random.randint(0, n - 1)
        col = random.randint(0, n - 1)
        while board.map[row][col] == 0:
            col = random.randint(0, n - 1)

        new_col = random.randint(0, n - 1)
        while new_col == col:
            new_col = random.randint(0, n - 1)

        board.flip(row, col)
        board.flip(row, new_col)

        new_fitness = board.get_fitness()
        if new_fitness < fitness:
            fitness = new_fitness
        else:
            board.flip(row, new_col)
            board.flip(row, col)

        max_attempts -= 1
        if max_attempts == 0:
            board = Board(n)
            fitness = board.get_fitness()
            max_attempts = 1000

    return board


if __name__ == '__main__':
    n = 5
    start_time = time.time()
    solution = hill_climbing(n)
    end_time = time.time()

    print(f"Running time: {int((end_time - start_time) * 1000)}ms")
    for row in solution.get_map():
        print(' '.join(['1' if cell == 1 else '-' for cell in row]))
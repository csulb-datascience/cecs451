import time
from board import Board
import random

start_time = time.time()
BOARD_SIZE = 5


def print_board():
    runtime = (time.time() - start_time) * 1000
    print("Running time:", '{0:.0f}'.format(runtime) + "ms")
    for row in board.get_map():
        for value in row:
            if value == 0:
                print("-", end=' ')
            else:
                print(value, end=' ')
        print()

def test_row(map, row_number):
    # create a list that will store the fitness values of the queen at each index
    fitness_levels = list(range(BOARD_SIZE))
    # loop through the row and flip the 1 to a 0
    for i in range(BOARD_SIZE):
        if map[row_number][i] == 1:
            board.flip(row_number, i)
    # test the queen at each index, saving the fitness value
    for j in range(BOARD_SIZE):
        board.flip(row_number, j)
        fitness_levels[j] = board.get_fitness()
        board.flip(row_number, j)
    # set score to the highest collision value
    score = BOARD_SIZE
    score_index = 0
    # loop through fitness values and find the index where the queen had the least collisions
    for i in range(BOARD_SIZE):
        if fitness_levels[i] < score:
            score_index = i
            score = fitness_levels[i]
    # flip the bit where the queen had the least collisions
    board.flip(row_number, score_index)


if __name__ == '__main__':
    # create board
    board = Board(BOARD_SIZE)
    # reset counter will prevent local minimum
    reset = 0
    infinite_loop = 0
    # while the optimal board is not found
    while board.get_fitness() > 0:
        # row that we will be testing is i
        i = 0
        # test each row in order
        while i in range(BOARD_SIZE):
            test_row(board.get_map(), i)
            # check reset value, and if it gets too high reset a random queen in the board
            # to escape local minimum
            if reset == 10:
                for randomize in range(0,BOARD_SIZE, 2):
                    for j in range(BOARD_SIZE):
                        if board.get_map()[randomize][j] == 1:
                            # find queen, flip her to 0
                            board.flip(randomize, j)
                            new = random.randrange(BOARD_SIZE - 1)
                            # flip new random bit in row to be a queen
                            board.flip(randomize, new)
                # bring reset back to 0
                reset = 0
            # increment counters
            i += 1
            reset += 1
    # optimal board is found, print board
    print_board()



import time
from board import Board


def hill_algorithm(board, restarts):
    res = board
    for _ in range(restarts):
        b = Board(board.n_queen)
        while True:
            nb = get_board(b)
            if nb.get_fitness() >= b.get_fitness():
                break
            b = nb
        if b.get_fitness() < res.get_fitness():
            res = b
    return res


def get_board(board):
    boards = []
    for i in range(board.n_queen):
        for j in range(board.n_queen):
            if board.map[i][j] == 1:
                b = create_new_board(board, i, j)
                boards.extend(b)

    res = boards[0]
    for item in boards:
        if item.get_fitness() < res.get_fitness():
            res = item

    return res


def create_new_board(board, row, col):
    arr = []
    for val in range(board.n_queen):
        if val != col:
            b = Board(board.n_queen)

            b.map = []
            for r in board.map:
                nr = r[:]
                b.map.append(nr)

            b.flip(row, col)
            b.flip(row, val)
            arr.append(b)
    return arr


def main():  # Done
    board = Board(5)
    restart = 7

    start = time.time()
    res = hill_algorithm(board, restart)
    end = time.time()

    times = (end - start) * 1000

    print("Running time: {:.0f}ms".format(times))

    for row in res.get_map():
        r = ''
        for element in row:
            r += '_' if element == 0 else '1'
            r += ' '
        print(r.strip())


if __name__ == "__main__":
    main()

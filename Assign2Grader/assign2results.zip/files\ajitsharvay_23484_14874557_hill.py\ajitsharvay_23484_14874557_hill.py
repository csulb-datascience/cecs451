import board
import time
import random as rand

st = time.time()

def hill(board_input):
    test = board_input
    curr_h = test.get_fitness()

    end = test.n_queen
    keep_running = True


    for i in range(test.n_queen):
        for j in range(test.n_queen):
            if test.map[i][j] == 1:
                final_i = i 
                final_j = j 
                for k in test.map[i]:
                    if j - 1 > -1: 
                        if test.map[i][j-1] != 1:    
                            test.map[i][j-1] = 1
                            test.map[i][j] = 0
                            temp_h = test.get_fitness()
                            if temp_h < curr_h:
                                curr_h = temp_h
                                if curr_h == 0:
                                    total_fit = test.get_fitness()
                                   
                                final_i = i
                                final_j = j - 1                         
                            
                            test.map[i][j-1] = 0
                            test.map[i][j] = 1

                for k in test.map[i]:
                    if j + 1 < test.n_queen: 
                        if test.map[i][j+1] != 1:
                            test.map[i][j+1] = 1
                            test.map[i][j] = 0
                            temp_h = test.get_fitness()
                            if temp_h < curr_h:
                                curr_h = temp_h
                                if curr_h == 0:
                                    total_fit = test.get_fitness()
                             
                                final_i = i
                                final_j = j + 1 
                            
                            test.map[i][j+1] = 0

                test.map[i][j] = 0
                test.map[final_i][final_j] = 1


      

    return test


check_h = 1
count = 0
max_iter = 50
while check_h != 0:
    test = board.Board(5)
    test = hill(test)
    check_h = test.get_fitness()
    while count < max_iter:
        check_h = test.get_fitness()
        count+=1
    count = 0
    

final_output = ""
for i in range (test.n_queen):
    for j in range(test.n_queen):
        if test.map[i][j] == 0:
            final_output += " - "
        else: 
            final_output += " 1 "
    final_output += "\n"

et = time.time()


print("Running time: " + str(round((et-st) * 1000)) + "ms" )
print (final_output)
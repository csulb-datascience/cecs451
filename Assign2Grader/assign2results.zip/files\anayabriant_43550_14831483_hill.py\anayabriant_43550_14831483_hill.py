from board import Board
import random
import time
import copy 

random.seed(random.randint(0, 100))

def hillClimbing(initialBoard):
    currentBoard = initialBoard
    bestFitness = currentBoard.get_fitness()
    noImprovementIterations = 0

    while bestFitness > 0:
        nextBoard = None
        nextFitness = float('inf')

        for row in range(currentBoard.n_queen):
            for col in range(currentBoard.n_queen):
                if currentBoard.map[row][col] != 1:
                    tempBoard = copy.deepcopy(currentBoard)
                    currentCol = tempBoard.map[row].index(1)
                    tempBoard.flip(row, currentCol)
                    tempBoard.flip(row, col)

                    tempFitness = tempBoard.get_fitness()
                    if tempFitness < nextFitness:
                        nextBoard = tempBoard
                        nextFitness = tempFitness

        if nextFitness < bestFitness:
            currentBoard = nextBoard
            bestFitness = nextFitness
            noImprovementIterations = 0
        else:
            noImprovementIterations += 1

        if noImprovementIterations > 30:
            currentBoard = Board(currentBoard.n_queen)
            bestFitness = currentBoard.get_fitness()
            noImprovementIterations = 0

    return currentBoard

def main():
    board = Board(5)
    solution = hillClimbing(board)
    
    print("Running time: {:.1f}ms".format((time.time() - startTime) * 1000))
    
    for i in  range(solution.n_queen):
        for j in range(solution.n_queen):
            if solution.map[i][j] == 1:
                print('1', end =  ' ')
            else:
                print('-', end = ' ')
        print()

startTime = time.time()

if __name__ == "__main__":
    main()
#by Aidan Tristen R. Angel
#ID Number 026226627
#CECS 451

from board import Board
import time

def hill_climbing(board_size):
    #Starts Timer
    start_time = time.time()


    #initializes a board with the size given.
    board = Board(board_size)
    #sets a loop that has the generated board be compared to a newly generated board until a
    #board with a fitness of 0 is found.
    while board.get_fitness() > 0:
        #generates new board to compare to
        next_board = Board(board_size)
        #if new board is better than old one, reassigns the new one as the main board to compare to.
        if next_board.get_fitness() < board.get_fitness():
            board = next_board

    #Ends Timer and converts to miliseconds
    end_time = time.time()
    running_time = int((end_time - start_time) * 1000)

    # prints the results in the format wanted.
    print("Running time:", f"{running_time} ms")
    # print("Solution:")
    for row in board.get_map():
        print(" ".join(["-" if x == 0 else "1" for x in row]))

if __name__ == '__main__':
    hill_climbing(5)
#Rayyan Ashraf 
import random
import time
from board import Board

def create_initial_population(size, n_queens):
    return [Board(n_queens) for _ in range(size)]

def calculate_fitness(board):
    # Fitness inversely proportional to the number of conflicts
    return 1 / (1 + board.get_fitness())

def tournament_selection(population, tournament_size=3):
    selected = random.sample(population, tournament_size)
    best = min(selected, key=lambda x: x.get_fitness())
    return best

def two_point_crossover(parent1, parent2):
    n = parent1.n_queen
    c1, c2 = sorted(random.sample(range(n), 2))
    child1, child2 = repair_crossover(parent1, parent2, c1, c2)
    return child1, child2

def repair_crossover(parent1, parent2, c1, c2):
    """A crossover mechanism that attempts to repair diagonal conflicts."""
    child1 = Board(parent1.n_queen)
    child2 = Board(parent2.n_queen)
    for i in range(parent1.n_queen):
        child1.map[i] = parent1.map[i] if i < c1 or i >= c2 else parent2.map[i]
        child2.map[i] = parent2.map[i] if i < c1 or i >= c2 else parent1.map[i]
    # Repair strategy could be applied here if necessary
    return child1, child2

def mutate(board, generation, max_generations):
    """Mutation rate adapts based on the generation."""
    mutation_rate = 0.05 + (0.1 - 0.05) * (generation / max_generations)  # Example adaptive rate
    for i in range(board.n_queen):
        if random.random() < mutation_rate:
            new_pos = random.randint(0, board.n_queen - 1)
            board.map[i] = [0] * board.n_queen
            board.map[i][new_pos] = 1

def genetic_algorithm(population_size, n_queens, generations):
    start_time = time.time()
    population = create_initial_population(population_size, n_queens)
    for generation in range(generations):
        new_population = [tournament_selection(population) for _ in range(population_size)]
        for i in range(0, population_size, 2):
            if i + 1 < population_size:
                child1, child2 = two_point_crossover(new_population[i], new_population[i+1])
                mutate(child1, generation, generations)
                mutate(child2, generation, generations)
                new_population[i], new_population[i+1] = child1, child2
        population = new_population
    best_solution = min(population, key=lambda x: x.get_fitness())
    end_time = time.time()
    print(f"Running time: {int((end_time - start_time) * 1000)}ms")
    for row in best_solution.map:
        print(' '.join(['1' if cell == 1 else '-' for cell in row]))

if __name__ == "__main__":
    genetic_algorithm(8, 5, 100)  # Population size set to 8


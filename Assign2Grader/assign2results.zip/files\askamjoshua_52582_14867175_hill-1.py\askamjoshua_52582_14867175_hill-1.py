import time

import board


def hill_climb(game: board.Board):
    game.get_map()
    # Keep track of the iterations to see if it is in a local maxima
    iterations = 0
    while game.get_fitness() != 0:
        # If it has gone through 5 iterations do a random restart
        # During testing, most iterations solve in less than 4 iterations
        if iterations == 5:
            game = board.Board(5)
            iterations = 0
        # Iterate through all rows
        for i in range(game.n_queen):
            # Keep track of the best index for a queen in a row.
            h = game.get_fitness()
            best_index = -1
            # Set all queens in the row to 0
            for j in range(game.n_queen):
                game.get_map()[i][j] = 0
            # Test all indices with the queen value. Keep the index that has the best fitness
            for j in range(game.n_queen):
                game.flip(i, j)
                if game.get_fitness() <= h:
                    h = game.get_fitness()
                    best_index = j
                game.flip(i, j)

            # Keep the best index
            game.flip(i, best_index)
        iterations += 1


def main():
    # Get the start time
    start_time = time.perf_counter()
    # Initialize the board
    game = board.Board(5)
    # Start algorithm
    hill_climb(game)
    # Get the end time
    end_time = time.perf_counter()

    # Calculate running time and round to the nearest ms
    running_time = round((end_time - start_time) * 1000)

    print("Running time:", str(running_time) + "ms")

    # Print the board
    for i in range(game.n_queen):
        for j in range(game.n_queen):
            if j == game.n_queen - 1:
                if game.get_map()[i][j] == 0:
                    print('-')
                else:
                    print('1')
            elif game.get_map()[i][j] == 0:
                print('- ', end='')
            else:
                print('1 ', end='')


if __name__ == '__main__':
    main()

from board import Board
import time
import random

#restart mechanism
def restart(n):
    queen = random.sample(range(n),n)
    board = Board(n)
    for i in range(n):
        board.map[i][queen[i]]=1
        return board

def hill_climbing(bd):
    curr_fit = bd.get_fitness()
    start = time.time()

    #Will loop until fitness is 0 or there is no optimal solution
    while curr_fit > 0:
        best_move =False
        for i in range (bd.n_queen):
            for j in range(bd.n_queen):
                if bd.get_map()[i][j] == 0:
                    #print("Before moving")
                    #print_board(bd)
                    #print(bd.get_fitness())
                    #flips the 0 to 1
                    bd.flip(i,j)
                    #locates the queen in the row
                    prev_queen = bd.map[i].index(1)
                    #flips the existing queen
                    bd.map[i][prev_queen]= 0
                    #takes the new fitness of the newly place queen
                    new_fit = bd.get_fitness()
                    #print("After moving")
                    #print_board(bd)
                    #print(bd.get_fitness())
                    #if the new fitness is 0 returns the time and board
                    if new_fit == 0:
                        end = time.time()
                        total = (end - start) * 1000
                        return bd, total
                    #if the new fitness is better then it keeps the board and fitness
                    elif new_fit < curr_fit:
                        curr_fit = new_fit
                        best_move = True
                    #if not better undos the move
                    elif new_fit > curr_fit:
                        bd.flip(i,j)
                        bd.map[i][prev_queen]= 1
         #if there are no better moves then it will call the resart mechanism       
        if not best_move:
            bd = restart(bd.n_queen)
            curr_fit = bd.get_fitness()
            
    #Default values if 0 fitness is not found
    return Board(bd.n_queen),0
#function to print out board
def print_board(board):
    for row in board.get_map():
        print(" ".join(["-" if cell == 0 else "1" for cell in row]))
        
if __name__ == '__main__':
    n = Board(5)
    bd,total = hill_climbing(n)
    print("Running Time: {:.0f}ms".format(total))
    print_board(bd)




   
    
    

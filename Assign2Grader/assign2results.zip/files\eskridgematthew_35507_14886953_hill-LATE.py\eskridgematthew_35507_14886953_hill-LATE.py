import board
import time

test = board.Board(5)
#print(test.get_fitness())
#print(test.get_map())

#Hill climb function
def hill_climb(t_board):
    current_board = t_board
    while True:
        #Calculate the fitness of the board and return it if solved
        current_fitness = current_board.get_fitness()
        if current_fitness == 0:
            return current_board

        best_neighbor = None
        best_fitness = current_fitness

        #Iterate over all cells on the board
        for i in range(current_board.n_queen):
            for j in range(current_board.n_queen):
                if current_board.get_map()[i][j] == 0:
                    #Create a new board and flip the current cell
                    neighbor_board = board.Board(current_board.n_queen)
                    neighbor_board.map = [row[:] for row in current_board.get_map()]
                    neighbor_board.flip(i, j)

                    #Measure new fitness and update the best neighbor
                    neighbor_fitness = neighbor_board.get_fitness()
                    if neighbor_fitness < best_fitness:
                        best_neighbor = neighbor_board
                        best_fitness = neighbor_fitness

        #Escape local maxima
        if best_neighbor is None:
            current_board = board.Board(current_board.n_queen)
        else:
            current_board = best_neighbor

#Start timer
start_time = time.time()

#Calculate solution
test = hill_climb(test)

#End timer
end_time = time.time()

#Calculate and print runtime
runtime = int((end_time - start_time) * 1000)
print(f"Running time: {runtime}ms")

#Print solution
for row in test.get_map():
    print(" ".join(['-' if x == 0 else '1' for x in row]))

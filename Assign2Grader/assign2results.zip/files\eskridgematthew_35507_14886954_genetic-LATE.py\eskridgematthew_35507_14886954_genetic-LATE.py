import board
import time
import random

test = board.Board(5)
#print(test.get_fitness())
#print(test.get_map())

#Genetic function
def genetic_climb(board_obj, generations=1000):
    population = [board.Board(board_obj.n_queen) for _ in range(100)]
    for _ in range(generations):
        #Sort the population and selects a new generation of 20
        population = sorted(population, key=lambda x: x.get_fitness())
        next_gen = population[:20]
        while len(next_gen) < 100:
            #Create child board, run it through the mutation function, and add it to the next generation
            parent1, parent2 = random.sample(population[:50], 2)
            child_board = crossover(parent1, parent2)
            mutate(child_board)
            next_gen.append(child_board)
        population = next_gen
    return population[0]

#Crossover
def crossover(parent1, parent2):
    n = parent1.n_queen
    #Create new child board composed of the first and second parent
    child_board = board.Board(n)
    for i in range(n):
        if i < n / 2:
            child_board.map[i] = parent1.map[i][:]
        else:
            child_board.map[i] = parent2.map[i][:]
    return child_board

#Mutate
def mutate(board_obj):
    #Move a random queen to a random column to add variation
    i = random.randint(0, board_obj.n_queen - 1)
    j = board_obj.map[i].index(1)
    board_obj.flip(i, j)
    k = random.randint(0, board_obj.n_queen - 1)
    board_obj.flip(i, k)

#Start timer
start_time = time.time()

#Calculate solution
test = genetic_climb(test)

#End timer
end_time = time.time()

#Calculate and print runtime
runtime = int((end_time - start_time) * 1000)
print(f"Running time: {runtime}ms")

#Print solution
for row in test.get_map():
    print(" ".join(['-' if x == 0 else '1' for x in row]))

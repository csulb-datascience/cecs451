import time

from board import Board
import math
import random
STATES = 8

def individual_to_board(indvidual):
    # convert all board to 0's
    N = len(indvidual)
    board = Board(N)
    #Edit board to a blank board
    for i in range(N):
        for j in range(N):
            if board.get_map()[i][j] == 1:
                board.flip(i, j)
    for row, queen in enumerate(indvidual):
       board.map[row][queen] = 1
    return board

def display(board):
    N = board.n_queen
    for i in range(N):
        if i > 0:
            print()
        for j in range(N):
            if board.map[i][j]:
                print(board.map[i][j], end = " ")
            else:
                print("-", end = " ")

#Given a board, make a list representation of Board where:
#each index is the row and each element tells you which column the queen is in
#[3,2,1] So the first row has a queen in column 3. Second row has a queen in column 2 and so on
def make_individual(board:Board):
    map_board = board.get_map()
    N = board.n_queen
    arr_board = map_board[:]
    for row in range(N):
        for col in range(N):
            if arr_board[row][col] == 1:
                arr_board[row] = col
                break;
    return arr_board

#Given a board, we calculate the total number of non-attacking pairs
#AKA: Take the fitness of board and subtract for total possible pairs "Combination from slides"

def get_non_attacking(board:Board):
    collisions = board.get_fitness()
    total = math.comb(board.n_queen, 2)
    h = total - collisions
    return h

#Make intervals based off weights, select random number, choose that

def selection(weights):
    rn = random.random()
    if rn < weights[0]:
        return 0
    elif rn < sum(weights[:1]):
        return 1
    elif rn < sum(weights[:2]):
        return 2
    elif rn < sum(weights[:3]):
        return 3
    elif rn < sum(weights[:4]):
        return 4
    elif rn < sum(weights[:5]):
        return 5
    elif rn < sum(weights[:6]):
        return 6
    else:
        return 7

def crossover(population, chosen):
    #2 at a time, grab two individuals -- pick a random splice -- and swap them
    N = len(population[0])
    res = []
    for n in range(STATES//2):
        indvidual1, indvidual2 = population[chosen[n]], population[chosen[n+1]]
        splice = random.randint(1, N - 1)
        child1, child2 = indvidual1[:splice]+indvidual2[splice:], indvidual2[splice:]+indvidual1[:splice]
        res.append(child1)
        res.append(child2)
    return res

def mutate(population):
    N = len(population[0])
    for individual in population:
        r = random.randint(-1,N-1)
        if(r > -1):
            individual[r] = random.randint(0,N-1)

def genetic(boards:Board):
    population = []
    for board in boards:
        population.append(make_individual(board))
    #Calculate weights by fitness
    weights = []
    fitness = []

    for board in boards:
        fitness.append(get_non_attacking(board))

    for n in range(len(boards)):
        weights.append(round(fitness[n]/sum(fitness),2))


    #Selection: Select individuals from population to be crossed-over
    #Create a list of chosen ones
    chosen = []
    for i in range(STATES):
        chosen.append(selection(weights))

    #Crossover: Iteratively, cross-over chosen to create new individuals
    population = crossover(population, chosen)

    #Mutate: Swap random queen to a random spot
    mutate(population)


    new_generation = []
    for individual in population:
        new_generation.append(individual_to_board(individual))

    #Check new population fitness'
    for board in new_generation:
        if(board.get_fitness() == 0): return board

    return None


if __name__ == "__main__":
    boards = []
    for _ in range(STATES):
        boards.append(Board(5))
    start_t = time.time()
    while True:
        res = genetic(boards)
        if(res): break
    end_t = time.time()
    print(f"Running time: {round((end_t - start_t) * 1000)}ms")
    display(res)
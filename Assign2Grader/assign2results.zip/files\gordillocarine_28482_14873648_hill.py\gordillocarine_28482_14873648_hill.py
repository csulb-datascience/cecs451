# Carine Gordillo
# 026110641
# CECS 451 
# Assignemnt 2

import board
import time

# function for finding all the possible wueen posiitions so we cna just inserts them 
def generateQueenPositions(boardSize):
    positions = []
    for i in range(boardSize):
        row = [0] * boardSize
        row[i] = 1
        positions.append(row)
    return positions

def hill_climbing_algo(gameBoard, boardSize):
    queenPositions = generateQueenPositions(boardSize) # get all possible queen posiitons for easy access
    improvement_found = True
# if we keep finding imporvements (not at a local maxima ) and we still have attacking pairs, keep going
    while improvement_found and gameBoard.get_fitness() != 0:
        improvement_found = False 

        for row in range(boardSize):
            for col in range(boardSize):
                temp_map = [r[:] for r in gameBoard.map]  #copy the gamebaord 
                #try different combinations 
                temp_map[row] = queenPositions[col] 

                tempBoard = board.Board(boardSize)
                tempBoard.map = temp_map

                tempFitness = tempBoard.get_fitness()

                if tempFitness < gameBoard.get_fitness(): # if we find an improvement break and return tot he wrapper hill climbing algo
                    gameBoard.map = temp_map
                    improvement_found = True
                    break  

            if improvement_found: #once we stop finding imporvements we return the game baord
                break  
    return gameBoard

def hillClimbing(boardSize):
    #hill climbing algo that allows random restart so we dont get stuck on local max 
    while True:
        gameBoard = board.Board(boardSize)  # Start with a new random board
        gameBoard = hill_climbing_algo(gameBoard, boardSize)
        if gameBoard.get_fitness() == 0:
            return gameBoard  


# turn board map into string output 
def formattedOutput(boardMap):
    string= ""
    for row in boardMap:
        for col in row:
            if col == 1:
                string += "1 "
            else:
                string += "- "
        string += "\n"

    return string


def main():
    boardSize = 5
    startTime = time.time()
    solution = hillClimbing(boardSize)
    endTime = time.time()
    print(f"Running time: {((endTime - startTime)*1000):.0f}ms")
    print(formattedOutput(solution.map))
        


main()

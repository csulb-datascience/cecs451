import time
from board import Board

def get_fitness(board):
    return board.get_fitness()

def get_neighbors(board):
    neighbors = []
    for i in range(board.n_queen):
        for j in range(board.n_queen):
            if board.map[i][j] != 1:
                neighbor_board = Board(board.n_queen)
                neighbor_board.map = [col[:] for col in board.map]
                neighbor_board.flip(i, j)
                neighbors.append((neighbor_board.get_fitness(), neighbor_board))
    return neighbors

def hill_climbing():
    start_time = time.time()
    n_queen = 5
    current_board = Board(n_queen)
    while True:
        fitness = current_board.get_fitness()
        if fitness == 0:
            running_time = round((time.time() - start_time) * 1000)
            return current_board.get_map(), running_time
        neighbors = get_neighbors(current_board)
        neighbors.sort(key=lambda x: x[0])
        best_neighbor_fitness, best_neighbor_board = neighbors[0]
        if best_neighbor_fitness >= fitness:
            current_board = Board(n_queen)
        else:
            current_board = best_neighbor_board

if __name__ == "__main__":
    solution, running_time = hill_climbing()
    print("Running time: {}ms".format(running_time))
    # print("Solution:")
    for row in solution:
        print(" ".join("1" if col == 1 else "-" for col in row))

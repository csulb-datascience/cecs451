from board import Board
from time import time


N = 5

# essentially copies the board2 to board 1
def record(board1, board2):
    ret = board1
    for i in range(N):
        for j in range(N):
            ret.map[i][j] = board2.map[i][j]
    return ret

# check if boards are the same
def compare(board1, board2):
    for i in range(N):
        for j in range(N):
            if board1.map[i][j] != board2.map[i][j]:
                return False
    return True


# changes the entire row to become 0
# perhaps it's not optimal because we don't necessarily record the original state, instead we just
# start the row from 0 and change indexes 1 by 1. However, still reaches local optima
def flip_row(board, j):
    new_board = board
    for i in range(N):
        new_board.map[j][i] = 0
    return new_board


def hill_climbing(c_board):
    # current state = start
    curr_state = c_board
    curr_fitness = curr_state.get_fitness()
    # initialize new board and copy it, so when we adjust new board and get a better fitness score we can change
    # current board to new baord
    new_state = Board(N)
    record(new_state, curr_state)
    for i in range(N):
        for j in range(N):
            # change row into 0 and change each index into 1 and recording fitness
            flip_row(new_state, i)
            new_state.map[i][j] = 1
            new_fit = new_state.get_fitness()
            # if new_fit < curr_fitness:
            #     record(curr_state, new_state)
            #     curr_fitness = new_fit
            #     # print(i)
            # elif curr_fitness == 0:
            #     print("fitness should be 0")
            #     print(new_state.get_map())
            #     print(new_state.get_fitness())
            #     break
            if curr_fitness == 0:
                break
            # if new fit is lower change curr state and fit to new fit
            elif new_fit < curr_fitness:
                record(curr_state, new_state)
                curr_fitness = new_fit
    return curr_state, curr_fitness

# surely there's a better syntax to do this type of stuff
def print_map(board):
    # loop through board and replace 0s with -
    for i in range(N):
        for j in range(N):
            if board.map[i][j] == 0:
                board.map[i][j] = "-"
    k = list(board.map)
    str_list = []
    # change arrays into a string and joining them
    for i in range(N):
        stringify = [str(ele) for ele in k[i]]
        res = ' '.join(stringify)
        str_list.append(res)
    # display strings line by line
    for i in range(N):
        print(str_list[i])
# Press the green button in the gutter to run the script.


if __name__ == '__main__':
    t0 = time()
    while True:
        init_board = Board(N)
        # t0 = time()
        x, y = hill_climbing(init_board)
        # t1 = time()
        if y == 0:
            break
    t1 = time()

    t = (t1 - t0) * 1000
    print('Running Time: ', int(round(t)), 'ms')
    print_map(x)


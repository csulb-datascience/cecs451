import board
import random
from datetime import datetime


def boardPrint(board_input: board):
    """
    Converts the board object instance variable map (2d list) into printing terminal format
    :param board_input: Input board parameter
    :return: None
    """
    for i in range(len(board_input.get_map())):
        printString = ""
        for j in range(len(board_input.get_map()[0])):
            if board_input.get_map()[i][j] == 0:
                # Not sure if the grader care if there is a space at the end of the string, so I made this if
                # statement just in case
                if j == len(board_input.get_map()) - 1:
                    printString += "-"
                else:
                    printString += "- "
            else:
                # Not sure if the grader care if there is a space at the end of the string, so I made this if
                # statement just in case
                if j == len(board_input.get_map()) - 1:
                    printString += str(board_input.get_map()[i][j])
                else:
                    printString += str(board_input.get_map()[i][j]) + " "
        print(printString)


def encodeState(board_input: board):
    """
    Get board state and place queen's location into a list.  Index = row, value = column
    :param board_input: Input board parameter
    :return: Board state encoded into a string
    """
    state = []
    for i in range(len(board_input.get_map())):
        for j in range(len(board_input.get_map()[0])):
            if board_input.get_map()[i][j] == 1:
                state.append(j)

    return state


def hill_climb(board_input: board, state: list):
    """
    Implement the hill climbing search algorithm
    :param board_input: Given board input
    :param state: Board state encoded as a list.  Index = row, value = column
    :return: The best fitness, should be 0 if a solution is found.
    - This algorithm manipulate the board object.  When this algorithm finishes, the board object should be
    configured to the solution
    """
    n = len(state)
    currentFitness = board_input.get_fitness()
    # The goal for this algorithm is to minimize the board's fitness.  Fitness is 0 when there is a solution to the n-
    # queens problem
    while currentFitness > 0:
        startFitness = currentFitness

        for i in range(n):
            for j in range(n):
                if j != state[i]:
                    # Flip the initial state
                    board_input.flip(i, state[i])
                    board_input.flip(i, j)
                    neighborFitness = board_input.get_fitness()
                    # If the neighborFitness is smaller than current Fitness, commit change
                    if neighborFitness < currentFitness:
                        state[i] = j
                        currentFitness = neighborFitness
                        if currentFitness == 0:
                            return currentFitness
                    # Revert changes if current fitness is >= neighborFitness
                    else:
                        board_input.flip(i, state[i])
                        board_input.flip(i, j)

        # If the current board is stuck on a plateau
        if startFitness == currentFitness:
            # Randomly select row and column
            row = random.randint(0, len(state) - 1)
            col = random.randint(0, len(state) - 1)
            # Flip the current row and column
            board_input.flip(row, state[row])
            state[row] = col
            # Flip the new row and column
            board_input.flip(row, col)
            currentFitness = board_input.get_fitness()



if __name__ == '__main__':
    # Mark start time for program
    startTime = datetime.now()

    # Create board object
    boardObject = board.Board(5)
    boardState = encodeState(boardObject)
    # Running hill search algorithm
    hill_climb(boardObject, boardState)

    # Mark end time when hill_climb search is finish
    endTime = datetime.now()

    # To find running time take the difference between endTime and startTime, multiplied by 1000
    timeDifference = (endTime - startTime).total_seconds() * 10 ** 3

    # Asked Dr. Moon about the run time after class, and he said we can do 2 decimal places
    print(f"Running time:{timeDifference: .2f}ms")
    boardPrint(boardObject)
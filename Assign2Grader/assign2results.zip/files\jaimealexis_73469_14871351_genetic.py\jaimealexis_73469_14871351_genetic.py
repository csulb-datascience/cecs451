# I will be utilizing the psuedocode and examples from geeksforgeeks, the textbook, and 
# the CMU CS program website 
from board import Board
import random
import time

def offspring_crossover(selected_parent1, selected_parent2):
    #this psuedo code from the geeks for geeks wesbite was used.
    for crossover_of_offspring in range (1, len(selected_parent2)):
        #purpose is to perform a crossover between a selected
        #pair of parents to create new offspring or a new gene pool
        firstParent = selected_parent1[crossover_of_offspring:]
        secondParent = selected_parent2[:crossover_of_offspring]
        new_genomic_offspring = firstParent + secondParent
    return new_genomic_offspring

def parent_selection(genomic_population, survival_rate):
    #CMU CS and Geeksforgeeks examples was used for this code
    genomic_parents = []
    for _ in range(2):
        #this will be used to select to random parents based
        #on the survivability rates
        counter = 0
        genome_selection = 0
        probability = random.uniform(0, 8)
        #Here we must conclude whether the parent will be used or not
        while counter < len(survival_rate):
            genome_selection += survival_rate[counter]
            if genome_selection >= probability:
                genomic_parents.append(genomic_population[counter])
                break
            counter += 1
        
    return genomic_parents
        
def genomic_mutation(genomic_offspring):
    #pseudo code from geeks for geeks website was used
    probability_of_mutation = random.random()
    #apply the genomic mutations to create changes in the offspring
    #to help with the optimal solution
    for x in range(len(genomic_offspring)):
            if probability_of_mutation < 0.05:
                genomic_offspring[x] = genomic_offspring[1 - x]
    return genomic_offspring

def genetic_algorithm(genomic_population, survival_rate):
    #psudocode was used from the textbook as it seem straightforward but implemented
    #CMU CS schools psuedocode too 
    whole_genetic_population = []
    while True:
        #must creat loops for the genetic algorithm to call the functions
        #of the main areas of this algorithm
        for _ in range(len(genomic_population)):
            selected_parent1, selected_parent2 = parent_selection(genomic_population, survival_rate)
        for _ in range(len(genomic_population)):
            genomic_offspring = offspring_crossover(selected_parent1.get_map(), selected_parent2.get_map())
        for _ in range(len(genomic_population)):
            genomic_offspring = genomic_mutation(genomic_offspring)
        #extension of the Board class to find optimal solution
        for _ in range(len(genomic_population)):
            whole_genetic_population.extend([Board(len(genomic_offspring))])
        #check conditions to ensure the population list not empty   
        if whole_genetic_population != 0:
            optimal_genetic_population = whole_genetic_population
        #calls the get_fitness() method on each board so we can get the survival rate
        survival_rate = [board.get_fitness() for board in optimal_genetic_population]
        #finds the offspring with the best fitness vlaue, use the lambda syntax
        # to get the fitness values from each individual
        best_genomic_fitness = min(optimal_genetic_population, key=lambda x: x.get_fitness())
        if best_genomic_fitness.get_fitness() <= 0: #checks best fitness value
            break
        
    return best_genomic_fitness

#main function for algorithm
if __name__ == "__main__":
    genetic_algorithm_population = []
    genetic_algoeithm_start = time.time()
    surviability = []
    #incorporating a set of 8 disinct states as required 
    for _ in range(8):
        board_state = Board(5)
        genetic_algorithm_population.append(board_state)
    #iterate and append the fitness calues of the  board to the fitness list
    for board_state in genetic_algorithm_population:
        surviability.append(board_state.get_fitness())
    
    most_optimal_solution = genetic_algorithm(genetic_algorithm_population, surviability)
    #The output will show the time on top in milliseconds and the matrix underneath
    genetic_algorithm_ending = time.time()
    total_algorithm_time = int((genetic_algorithm_ending - genetic_algoeithm_start)) * 1000
    #formatted the code ot ensure the output is correct
    print( f"Running time: {total_algorithm_time}ms")
    for x in most_optimal_solution.get_map():
        output = ""
        for y in x:
            if y != 1:
                output += "- "
            else:
                output += "1 "
        print(output)
    
    
    
# Alexander Ly 027744520
# CECS 451 Sec 01
# Assignment 2 - Local Search
# February 14, 2024

from board import Board
import time
import random

# implement selection
def selection(population, fitness):
    # calculate sum of all the fitnesses from the 8 boards
    total_fitness = sum(fitness)
    # get the percentage of each fitness being selected, subtract from 1 since we want lower fitness
    percentage = [1 - (f / total_fitness) for f in fitness]

    # calculate sum of the percentages
    add_percentage = sum(percentage)
    # make percentages sum to 1 to indicate 100% 
    percentage = [p / add_percentage for p in percentage]
    # select the boards based on random probability and the boards
    selected_boards = random.choices(population, weights=percentage, k=len(population))

    return selected_boards

#implement crossover
def crossover(parent1, parent2):
    # get the size of the board
    n = len(parent1.get_map()) 
    # select a random crossover point where we split the parents
    crossover = random.randint(0, n-1)
    # perform the crossover between the parents where the randint is selected
    new_board1 = parent1.get_map()[:crossover] + parent2.get_map()[crossover:]
    new_board2 = parent2.get_map()[:crossover] + parent1.get_map()[crossover:]
    # create new boards based on the crossover we completed between the parents
    crossover1 = Board(len(new_board1))
    crossover2 = Board(len(new_board2))
    # assign the new genetic map to the board
    crossover1.map = new_board1
    crossover2.map = new_board2

    return crossover1, crossover2

# implement mutation
def mutation(child):
    # selects a random row from the 8 (basically a random spot on genetic strip)
    row = random.randint(0, len(child.map) - 1)
    # set the row to all 0's which will remove the current queen in that row
    child.map[row] = [0] * len(child.map)
    # select a random column from the 8
    column = random.randint(0, len(child.map) - 1)
    # place a 1 at the row and column that was selected representing a queen
    child.map[row][column] = 1

# implement genetic algorithm
def genetic(population, fitness):
    # start while loop until we reach the max_generations or fitness reaches 0
    while True:
        # run our selection function which selects 8 boards 
        boards = selection(population, fitness)

        # create a list to store our crossover boards
        crossover_boards = []
        # loop to iterate over the board pairs 
        for i in range(0, len(boards), 2):
            # run crossover and store them in variable child1 and child2
            child1, child2 = crossover(boards[i], boards[i+1])
            # store the child1 and child2 into our list
            crossover_boards.extend([child1, child2])

        # run our mutation function on all the crossover boards that we created
        for child in crossover_boards:
            mutation(child)

        # get the fitness of all the childs after their mutation
        child_fitness = [child.get_fitness() for child in crossover_boards]

        # update our population and fitness with new children
        population = crossover_boards
        fitness = child_fitness

        # check for the lowest fitness of the newly created children
        lowest_fitness = min(fitness)
        # if any of children's fitness is 0, break
        if lowest_fitness == 0:
            break
    
    # return the child with the fitness score of 0
    optimal_child = fitness.index(min(fitness))
    return population[optimal_child]

# main
if __name__ == '__main__':
    # calculate start time
    start = time.time()
    # generate the amount of boards we want and the size of the boards
    population = [Board(5) for i in range(8)]
    # get the fitness of each of boards
    fitness = [board.get_fitness() for board in population]
    # run our genetic function with our population and fitness
    run = genetic(population, fitness)
    # calculate end time of code
    end = time.time()
    # calculate final time and multiply by 1000 for ms
    final_time = end-start 
    final_time = final_time * 1000
    rounded_final_time = round(final_time)
    # output
    print("Running time: ", rounded_final_time, "ms")
    for row in run.get_map():
        print(" ".join(['-' if dash == 0 else '1' for dash in row]))

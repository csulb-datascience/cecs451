import time
import random #FIXME: this library is currently not being used
from board import Board

def neighbors_state(board, row_index):
	'''
	Generate neighboring states of the current board.

	Args:
		board: An instance of the Board class representing the current state of the board.

	Returns:
		A list of neighboring states (instances of the Board class).
	'''

	# Get the length of the array on the board
	n = board.n_queen

	# Initialize a list for neighboring states
	neighboring_states = []

	for col in range(n):
		# Create a new neighboring state by copying the current state
		new_state = Board(n)
		new_state.map = [row[:] for row in board.map]

		# Set all values in the targeted row to 0
		new_state.map[row_index] = [0] * n

		# Create a new neighboring state (5 states)
		new_state.flip(row_index, col)

		#print(f"{col + 1}. {new_state.get_map()}\n")

		# Append the new state to the list
		neighboring_states.append(new_state)

	return neighboring_states

def hillClimbing_algorithm(board, max_iter=1000):
	'''
	Performs the hill-climbing algorithm to solve the n-queens problem.

	Args:
		board: An instance of the Board class representing the current state of the board.

	Returns:
		An instance of the board class representing the optimal solution.
	'''
	iteration = 0
	# The current state of the board
	current_board = board

	while iteration < max_iter:
		# Get the fitness (cost) of the current state
		current_fitness = current_board.get_fitness()

		# If there are no attacking queens, a solution was found
		if current_fitness == 0:
			break

		# Get the size of the current board (using the number of queens)
		n = current_board.n_queen

		# Initialize variables to track the best state and its fitness
		best_state = current_board
		best_fitness = current_fitness

		# Generate all the neighboring states and find the min cost function 'h'
		for i in range(n):
			neighboring_states = neighbors_state(current_board, i)

			# Check fitness of each neighboring state and choose the min cost
			for neighbor_state in neighboring_states:
				neighbor_fitness = neighbor_state.get_fitness()
				if neighbor_fitness < best_fitness:
					best_state = neighbor_state
					best_fitness = neighbor_fitness

		# Update the current_board to the chosen neighboring state
		current_board = best_state

		iteration += 1

	# execute a random restart
	if iteration == max_iter:
		current_board = Board(current_board.n_queen)
		return hillClimbing_algorithm(current_board, max_iter)

	return current_board

def print_board(board):
	for row in board.map:
		print(" ".join(["-" if cell == 0 else "1" for cell in row]))

def main():
	# initialize the board
	board = Board(5)


	start_time = time.time()

	#print(f"\nAttempting to find optimal solution using Hill-Climbing algorithm\n")
	#print(f"Before: {board.get_map()}\n")
	solution = hillClimbing_algorithm(board)

	end_time = time.time()
	runtime = (end_time - start_time) * 1000

	#print(f"Optimal solution was found probably")
	print(f"Running time: {runtime:.2f}ms")
	#print(solution.get_map())
	print_board(solution)


if __name__ == "__main__":
	main()
#Program Name: hill.py
#Name: Aidan Mara
#Date 2/16/2024
#Version: 1.1

###############################
import random
import time
import math
import copy

from board import Board
###############################

######################### Start of Hill Climbing Algorithm #########################


def hillClimb(b):
  ######################### Initilizations #########################

  startingState = b

  #Initilize the time stamp to output runtime
  initTS = time.time()

  #Initilize the best score to the infinity
  #We want to minimize this
  bestScore = math.inf

  #i is the tracking which row we are visiting
  i = 0

  #These two are to random restart at some point
  its = 0
  itCap = len(startingState.map) * 2

  ##################### End of Initilizations #####################

  ######################### Main Loop #########################

  #Will run until a fitness score with no attacking queens is found
  while bestScore != 0:

    #Create n copies of the starting state where n is the number of columns
    #Deep copy is copy but allows for nested objects (In this case the map).
    possibilities = [
        copy.deepcopy(startingState) for _ in range(len(startingState.map))
    ]

    choicesList = []
    currLow = bestScore

    #In n possibilities, for this row, make each copy have that possibility and evaluate fitness score
    for p in range(len(startingState.map[0])):
      possibilities[p].map[i] = list([0] * p + [1] + [0] *
                                     (len(startingState.map[0]) - p - 1))

      #Evaluate the fitness score of each possibility, if one is smaller than current save it to the current choices list
      if possibilities[p].get_fitness() < currLow:
        currLow = possibilities[p].get_fitness()
        choicesList = [possibilities[p]]
      elif possibilities[p].get_fitness() == currLow:
        choicesList.append(possibilities[p])

    #By selecting a random choice of the lowest scores we can avoid getting stuck on a local hill
    bestScore = currLow
    startingState = random.choice(choicesList)

    #If we have gone through all the columns and have not found a solution, we have to restart.
    if i == len(startingState.map) - 1:
      i = 0
      #Keep track of iterations total for random restart
      its += 1
    else:
      i += 1

    #Check if the best score is not decreasing after a certain number of iterations
    if its >= itCap:
      for index in range(itCap):
        #Create a random state with our size
        randState = Board(len(startingState.map))
        startingState = randState
        bestScore = randState.get_fitness()
        its = 0
        break
  ##################### End of Main Loop #####################

  #Print running time in ms
  print('Running time: ', int((time.time() - initTS) * 1000), 'ms')

  #Print the map in the format provided
  for row in startingState.map:
    s = ''
    for column in range(len(row)):
      if row[column] == 0:
        s += ' - '
      else:
        s += ' 1 '
    print(s)


#########################################################################################


def main():
  test = Board(5)
  hillClimb(test)


main()

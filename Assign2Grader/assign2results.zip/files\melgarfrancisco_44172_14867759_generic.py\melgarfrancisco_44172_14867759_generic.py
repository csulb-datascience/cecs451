import random
import time
from board import Board


def genetic():
    size = 5
    population = 10
    generations = 100
    start = time.time()

    # Initialize the population with random states
    population = [Board(size) for _ in range(population)]

    for generation in range(generations):
        # Calculate fitness for each individual in the population
        fitness = [individual.get_fitness() for individual in population]

        # Find the index of the individual with the minimum fitness score
        min_index = fitness.index(min(fitness))

        # Check if any individual has fitness 0
        if fitness[min_index] == 0:
            end = time.time()
            time_ms = round((end - start) * 1000, 1)
            print("Time:", time_ms, "ms")
            return population[min_index].get_map(), 0

        # Select two parents using tournament selection
        parent1 = tournament_selection(fitness)

        # Ensure max fitness index is not the same as parent1
        max_index1 = fitness.index(max(fitness))
        max_index2 = max_index1

        while max_index2 == max_index1:
            max_index2 = tournament_selection(fitness)

        # Perform crossover and mutation
        child1, child2 = crossover(population[parent1].get_map(), population[max_index2].get_map())
        child1 = mutate(child1)
        child2 = mutate(child2)

        # Replace  with the highest fitness value
        population[min_index] = Board(size)
        population[max_index1] = Board(size)

    end = time.time()
    time_ms = round((end - start) * 1000, 1)
    print("Time:", time_ms, "ms")

    # Return the best state and its fitness
    return population[min_index].get_map(), min(fitness)


def tournament_selection(fitness, size=2):
    # Select random individuals for the tournament
    indices = random.sample(range(len(fitness)), size)
    # Return the index of the individual with the minimum fitness score in the tournament
    return min(indices, key=lambda i: fitness[i])


def crossover(parent1, parent2):
    # Perform single-point crossover
    point = random.randint(1, len(parent1) - 1)
    child1 = parent1[:point] + parent2[point:]
    child2 = parent2[:point] + parent1[point:]
    return child1, child2


def mutate(individual):
    # Perform mutation by flipping a random cell in the individual
    row = random.randint(0, len(individual) - 1)
    col = random.randint(0, len(individual) - 1)
    individual[row][col] = 1 - individual[row][col]
    return individual


if __name__ == "__main__":
    best_state, best_fitness = genetic()
    # print("Best State:")
    for row in best_state:
        print(" ".join(map(lambda x: '-' if x == 0 else '1', row)))


# Daniel Moreno
# CECS 451-01 Aritificial Intelligence
# Due Date: February 16, 2024

# Importing the provided file to import board class and time module from python library
from board import Board
import time

# Creates a starting board for the algoritm
def generate_board() -> Board:
    FIVE_QUEENS = 5
    return Board(FIVE_QUEENS)

# Makes small changes to the position of a current row
# moves one queen in the same row to find best position 
# for that queen in that row
def neighbor_solutions(board,row) -> Board:
    # Board was being copied over, that didnt work
    # Instead I will just record the column as a key 
    # with fitness as its value
    neighbor_solutions = {}

    # Loops 5 times since there are only 5 possible 
    # columns a queen can be at
    LOOPS_AMOUNT = 5

    # Makes whole row 0 to avoid more than 1 queen in same row
    for column in range(LOOPS_AMOUNT):
        board.map[row][column] = 0

    # Here I am going through each column, changing its value from 0 to 1
    # Then record the current column with the fitness at this moment
    # then added to the dictionary to find least later
    # changing value from 1 to 0 again to not have multiple queens
    for column in range(LOOPS_AMOUNT):
        board.flip(row, column)
        neighbor_solutions.update({column:board.get_fitness()})
        board.flip(row, column)

    # Choosing the key (in this case column) with the best fitness, and making that row, column pair a queen's
    # position on the board, this board is then returned
    # https://stackoverflow.com/questions/26660654/how-do-i-print-the-key-value-pairs-of-a-dictionary-in-python
    best_column = min(neighbor_solutions, key = neighbor_solutions.get)
    board.map[row][best_column] = 1

    return board

# Implementing the hill climbing algorithm logic
def hill_climbing_algorithm() -> list:
    # Generates a new board and checking its initial fitness
    current_board = generate_board()
    fitness = current_board.get_fitness()
    row = 0 # Row indicates search space (a single row at a time)

    # Here looping for 25 times, I thought, since this is a 5x5 board
    # it should take around n^2 times to solve (n = 5 here, so 5^2 = 25)
    for i in range(25):
        # Obtains the best board based on the neighboring solution provided
        # by above function
        neighbor = neighbor_solutions(current_board, row)        
        # Simple comparison, if new fitness is better than the old fitness, update
        if neighbor.get_fitness() < fitness:
            current_board = neighbor
            fitness = neighbor.get_fitness()

        # if fitness becomes 0 before the loop, it returns that board before loop ends
        elif fitness == 0:
            break

        # Easy way to determine what row the algoritm should be looking at
        row = (row + 1) % 5
    # Returns the best board at the moment (could be best global board) as well as fitness    
    return [current_board, fitness]

# Will run the hill climb algorithm with fixed restarts
# in order to avoid local maxima (number fixed after taking note
# around how many restarts in general to find best solution)
def hill_climbing_restart() -> Board:
    # Keeping track of best board
    # initialized with no best board and worst possible fitness
    best_board = None
    best_fitness = 10

    # Simulates a "restart" to avoid local maxima
    # After running a few times, it seems 15ish should be about right
    for i in range(15):
        # Calling the actual hill_algorithm and saving the values for later comparison
        returned_board = hill_climbing_algorithm()
        current_board = returned_board[0]
        current_fitness = returned_board[1]

        # Checks if the new board is better than the old board
        # If so, updates to hold the best board
        if current_fitness < best_fitness:
            best_fitness = current_fitness
            best_board = current_board

        # If the current board is already 0, loop terminated before getting
        # to the 15th iteration
        elif current_fitness == 0:
            break

    # This should be the optimal board!
    return best_board

# Main entrypoint of the file
def main() -> int:
    # Converting seconds to miliseconds by multiplying by 1000
    S_TO_MS = 1000

    # Starts the time using python's time module
    start = time.time()
    # Calls the function to start the search
    final_board = hill_climbing_restart()
    # Ends the time to calculate how long the algoritm took
    end = time.time()
    # Calculating and printing output, no trailing decimals
    total_time = (end - start) * S_TO_MS
    print(f"Running time: {total_time:.2f}ms")

    board_print = ""
    #Printing the board to look like the instructions
    # Iterates 5 times per row and column since it is a 5x5 board
    for row in range(5):
        for column in range(5):
            # Replaces 0's with -'s and places 1's
            if final_board.map[row][column] == 0:
                board_print += '- '
            else:
                board_print += '1 '
        # Removes extra space at the end
        board_print = board_print[:-1]
        # Adds new line so board looks like a board (not all on one line)
        # Then prints
        board_print += '\n'
    print(board_print)
    # If program successful, returns 0 (like in C)
    return 0

# Main function call
main()

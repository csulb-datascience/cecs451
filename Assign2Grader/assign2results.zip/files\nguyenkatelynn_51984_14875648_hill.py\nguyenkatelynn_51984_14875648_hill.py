import board
import time
import random


# location positions of queens on board
def location_queen(queen_board):
    queen_pos = []
    # iter through each row to find pos, then append/store
    # into queen_pos list
    for row in queen_board:
        queen_index = row.index(1)
        queen_pos.append(queen_index)
    return queen_pos


def hill_climb(board):
    board_fitness = board.get_fitness()
    curr_board_map = board.get_map()
    curr_board = board

    # looping until solution is found
    while board_fitness > 0:
        if board_fitness == 0:
            return curr_board
        queen_neighbors = location_queen(curr_board_map)

        row = 0

        while row < len(queen_neighbors):
            if board_fitness == 0:
                return curr_board

            curr_board.flip(row, queen_neighbors[row])
            valid_pos = []

            # iterates through each column pos, placing a temp
            # queen in each pos
            for i in range(len(curr_board_map[row])):
                curr_board.flip(row, i)
                valid_pos.append(curr_board.get_fitness())
                curr_board.flip(row, i)

            queen_pos = queen_neighbors[row]
            for j in range(len(valid_pos)):
                if board_fitness > valid_pos[j]:
                    board_fitness = valid_pos[j]
                    queen_pos = j
                elif board_fitness == valid_pos[j]:
                    rand_choice = random.randint(0, 1)
                    if rand_choice == 1:
                        board_fitness = valid_pos[j]
                        queen_pos = j

            # flips queen pos to lowest fitness value and
            # increments row index
            curr_board.flip(row, queen_pos)
            row += 1

    return board


def display_board_pos(board):
    for row in board.map:
        for i in row:
            if i == 1:
                print("1", end=" ")
            else:
                print("-", end=" ")
        print()


if __name__ == "__main__":
    given_n_queens = board.Board(5)
    start_time = time.time()
    queen_solution = hill_climb(given_n_queens)
    end_time = time.time()
    print("Running time:", round((end_time - start_time) * 1000), "ms")
    display_board_pos(queen_solution)

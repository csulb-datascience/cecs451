import copy
from board import Board
import time

"""
random reset = make a new board entirely
create board
choose random queen
move queen entire row and check for h
if new.h < curr.h, pick the new.h
keep going until reach end of row
new board to check is the current board + the next row
(keep the queens of the best board and move the next row of queens)
if h != 0, reset board and do the same thing
"""

def hill_climbing():
    start = time.time_ns()
    start_queen_loc = -1
    board = Board(5)  # 5x5
    # print("ORIGINAL BOARD", board.get_map())
    # print("fitness: ", board.get_fitness())
    current_board = copy.deepcopy(board)

    # loop hill_search until we get an objective function value of 0
    while current_board.get_fitness() != 0:
        current_board = copy.deepcopy(board)
        # loop through row
        for i in range(board.n_queen):
            # copy the current board and change the row we are checking.
            #  find a better board during the check, want the locations of the locked in Qs
            board = copy.deepcopy(current_board)
            # gets index of the queen for that row
            for j in range(board.n_queen):
                if board.map[i][j] == 1:
                    start_queen_loc = j

            # loop through column
            for j in range(board.n_queen):
                # flip the original queen to not have two queens on one row and
                # flip the value for the current location to a queen
                board.flip(i, start_queen_loc)
                board.flip(i, j)

                # if the new board is better than the current board, copy the current board
                if board.get_fitness() < current_board.get_fitness():
                    current_board = copy.deepcopy(board)

                # re-flip the board to before the change
                # allowing the next iteration to proceed
                board.flip(i, j)
                board.flip(i, start_queen_loc)

        # if we do not have the best board, random reset and continue
        if current_board.get_fitness() != 0:
            # print("new board")
            board = copy.deepcopy(Board(5))
    end = time.time_ns()
    running_time_ms = (end - start) / 1000000
    # round time to nearest ms
    rounded_running_time = round(running_time_ms)

    print(f'Running Time: {rounded_running_time} ms')
    for i in range(current_board.n_queen):
        for j in range(current_board.n_queen):
            if current_board.map[i][j] == 0:
                print('-', end=" ")
            else:
                print(current_board.map[i][j], end=" ")
        print()

if __name__ == '__main__':
    hill_climbing()

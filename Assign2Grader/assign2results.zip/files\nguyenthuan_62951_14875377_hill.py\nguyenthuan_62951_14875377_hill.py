import time
from board import Board
def hill_climbing(board):
    restarts = 0
    while restarts < 50:
        current_fitness = board.get_fitness()
        if current_fitness == 0:
            return board
        best_move = None
        best_fitness = current_fitness
        for i in range(board.n_queen):
            for j in range(board.n_queen):
                if board.map[i][j] == 1:
                    for k in range(board.n_queen):
                        if k != j:
                            board.flip(i, j)
                            board.flip(i, k)
                            new_fitness = board.get_fitness()
                            if new_fitness < best_fitness:
                                best_fitness = new_fitness
                                best_move = (i, j, k)
                            board.flip(i, j)
                            board.flip(i, k)
        if best_move is not None:
            i, current_position, new_position = best_move
            board.flip(i, current_position)
            board.flip(i, new_position)
        else:
            board = Board(board.n_queen)
            restarts += 1
def print_board(board_map):
    for row in board_map:
        print(' '.join(['1' if x == 1 else '-' for x in row]))

if __name__ == '__main__':
    initial_board = Board(5)
    start_time = time.time()
    solution = hill_climbing(initial_board)
    end_time = time.time()
    print("Running time: {}ms".format(round((end_time - start_time) * 1000)))
    print_board(solution.get_map())



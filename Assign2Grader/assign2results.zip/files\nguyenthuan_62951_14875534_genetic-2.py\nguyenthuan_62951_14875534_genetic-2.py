import time
import random
from board import Board
def initialize_population(size, n_queen):
    return [Board(n_queen) for _ in range(size)]

def selection(population):
    sorted_population = sorted(population, key=lambda board: board.get_fitness())
    return sorted_population[:2]

def crossover(parent1, parent2):
    n = parent1.n_queen
    child = Board(n)
    crossover_point = random.randint(1, n - 2)
    for i in range(n):
        if i < crossover_point:
            child.map[i] = parent1.map[i][:]
        else:
            child.map[i] = parent2.map[i][:]
    return child

def mutate(board, mutation_rate):
    for i in range(board.n_queen):
        if random.random() < mutation_rate:
            new_position = random.randint(0, board.n_queen - 1)
            board.map[i] = [0] * board.n_queen
            board.flip(i, new_position)

def genetic_algorithm(n_queen, mutation_rate, population_size, generations):
    population = initialize_population(population_size, n_queen)
    for _ in range(generations):
        new_population = []
        while len(new_population) < population_size:
            parent1, parent2 = selection(population)
            children = crossover(parent1, parent2)
            mutate(children, mutation_rate)
            new_population.append(children)
        population = new_population
        for board in population:
            if board.get_fitness() == 0:
                return board

def print_board(board_map):
    for row in board_map:
        print(' '.join(['1' if x == 1 else '-' for x in row]))

if __name__ == '__main__':
    start_time = time.time()
    solution = genetic_algorithm(5, 0.1, 8, 500)
    end_time = time.time()
    print("Running time: {}ms".format(round((end_time - start_time) * 1000)))
    print_board(solution.get_map())

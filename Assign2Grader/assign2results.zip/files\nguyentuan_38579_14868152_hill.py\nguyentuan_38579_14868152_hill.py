# Tuan Nguyen
# Assignment_2    N_Queens problem
# CECS 451 Professor Moon
# Algorithm citation:
# This algorithm is based on the hill climbing algorithm for the N-Queens problem found on geeksforgeeks.org.
# Author(s): Prasantkp
# URL: https://www.geeksforgeeks.org/n-queen-problem-local-search-using-hill-climbing-with-random-neighbour/?ref=header_search
# ------------------------------------------------------
#ChatGPT. (2024, February 12). Re: hill climbing Algorithm for N-Queens Problem [Personal Communication].

import time
import copy
from board import Board

num_of_Queens = 5


def hill_climbing():
    # get chess board and fitness from board.py
    current_state = generate_board(num_of_Queens)
    current_fitness = current_state.get_fitness()

    # fitness should be 0, which means no queens are in attacking range of other queens
    # iterate until fitness reaches 0
    # generate neighbors states, select the best the neighbors with the best fitness score and update its current state
    while current_fitness > 0:
        neighbors = generate_neighbors(current_state)  # generate neighbors base on current state of board
        next_state = select_best_neighbor(neighbors)  # get the best neighboring state from our list
        next_fitness = next_state.get_fitness()
        # compare the states of current and next
        current_state, current_fitness = compare_fitness(next_fitness, current_fitness, next_state)

    return current_state.get_map()


def compare_fitness(next_fitness, current_fitness, next_state):
    if next_fitness >= current_fitness:
        # Local optimum reached, perform random restart
        current_state = generate_board(num_of_Queens)
        current_fitness = current_state.get_fitness()
    else:
        current_state = next_state
        current_fitness = next_fitness

    return current_state, current_fitness


def generate_board(num_of_queens):
    # get chess board from board.py
    return Board(num_of_queens)


def generate_neighbors(board):
    neighbors = []
    current_map = board.get_map()
    n = board.n_queen  # size of board, the number of queens from board.py

    # iterate over each positions on chess board with n size
    for i in range(n):
        for j in range(n):
            # if no queen at position i, j, then create new board with same size
            if current_map[i][j] == 0:
                neighbor = Board(n)
                neighbor.map = copy.deepcopy(current_map)  # Deep copy the current map
                neighbor.flip(i, j)  # place a queen here
                neighbors.append(neighbor)
    return neighbors


def select_best_neighbor(neighbors):
    # Select the neighbor with the lowest number of attacking pairs
    # for each board in the neighbors list, get the fitness and return the min value board
    best_neighbor = min(neighbors, key=lambda board: board.get_fitness())
    return best_neighbor


if __name__ == "__main__":
    start_time = time.time()
    optimal_solution = hill_climbing()
    end_time = time.time()

    total_time = (end_time - start_time) * 1000

    print(f"Running time: {round(total_time)}ms")
    for row in optimal_solution:
        print(" ".join(map(lambda x: "-" if x == 0 else "1", row)))



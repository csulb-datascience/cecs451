import time
import random
from board import Board

# hill climb initial function to use with the random restarting afterwards
def hillClimb(board):
    boardNow = board
    boardFitnessNow = boardNow.get_fitness()
    while True:
        otherBoards = []
        for i in range(boardNow.n_queen):
            for j in range(boardNow.n_queen):
                if boardNow.get_map()[i][j] == 1:
                    continue
                boardNext = Board(boardNow.n_queen)
                boardNext.map = [row[:] for row in boardNow.get_map()]
                boardNext.flip(i, j)
                fitnessNext = boardNext.get_fitness()
                otherBoards.append((boardNext, fitnessNext))
        optimalBoard, optimalBoardFitnessScore = min(otherBoards, key=lambda x: x[1])
        if optimalBoardFitnessScore >= boardFitnessNow:
            break
        boardNow = optimalBoard
        boardFitnessNow = optimalBoardFitnessScore
    return boardNow, boardFitnessNow

# function with hill climbing and random restarts so that it doesn't get stuck in local minima
def hillClimbing(n, maxAmountRestarts=1000):
    timeInitial = time.time()
    optimalSolution = None
    optimalFitnessScore = float('inf')
    for _ in range(maxAmountRestarts):
        boardInitial = Board(n)
        boardOutcome, boardFitness = hillClimb(boardInitial)
        if boardFitness == 0:
            return boardOutcome, time.time() - timeInitial
        if boardFitness < optimalFitnessScore:
            optimalSolution = boardOutcome
            optimalFitnessScore = boardFitness
    return optimalSolution, time.time() - timeInitial

if __name__ == "__main__":
    boardOutcome, runningTime = hillClimbing(5)
    boardMap = boardOutcome.get_map()
    print(f"Running time: {runningTime * 1000:.0f}ms")
    for row in boardMap:
        print(" ".join(['-' if cell == 0 else '1' for cell in row]))

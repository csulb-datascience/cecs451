import time
from board import Board
import sys
StartTime = time.time()

#CHANGE THIS VALUE IF YOU WANT MORE QUEENS OR LESS. Board size is begin * begin
begin = 5
MyBoard = Board(begin)
fitness = MyBoard.get_fitness()
# print("Fitness:", fitness) # Number of attacking queens
# tmp = MyBoard.get_map()
# print("Current board state:", tmp)
# for row in tmp:
#     print(' '.join(['1' if cell == 1 else '-' for cell in row]))
# print("hill climb")  
iteration = 0

while fitness > 0 and iteration < 100:
    iteration+=1
    #print("hi") 
    #iterate through rows and columns.
    #temp = None
    for row in range(MyBoard.n_queen):
        for col in range(MyBoard.n_queen):
            #if MyBoard.map[row][col] == 1: # do nothing
                #print("Queen at", row, col)
            if MyBoard.map[row][col] == 0: #Try moving the queen to this spot and check fitness
                #print("No queen at", row, col)
                og = MyBoard.map[row].index(1) #Get position of queen
                MyBoard.flip(row, og) #1 to 0
                MyBoard.flip(row, col) #0 to 1
                new_fitness = MyBoard.get_fitness()
                if new_fitness < fitness:
                    fitness = new_fitness
                    #temp = (row, col)
                else: #Make it go back to original location
                    MyBoard.flip(row, og) #1 to 0
                    MyBoard.flip(row, col) #0 to 1
            if fitness == 0:
                break
    if fitness == 0:
        break
    # RANDOM RESTART MECHANISM #
    if iteration == 100: # Random restart mechanism
        #print("Max iterations reached")
        iteration=0
        MyBoard = Board(begin)
        fitness = MyBoard.get_fitness()
        
EndTime = time.time()
TotalTime = (EndTime - StartTime) * 1000
# print(f"Running time: {TotalTime:.2f}ms") # IF YOU WANT MORE DECIMALS
print(f"Running time: {TotalTime:.0f}ms")
for row in MyBoard.map:
    print(' '.join(['1' if cell == 1 else '-' for cell in row]))
# print("Fitness:", fitness)
import board
import time

BOARD_LENGTH = 5

cur_board = board.Board(BOARD_LENGTH)

def find_queen_position(board_map, row):
    for col, value in enumerate(board_map[row]):
        if value == 1:
            return col
    return None

def main():
    cur_row = 0
    restarts = 0
    cur_board = board.Board(BOARD_LENGTH)

    cur_fit = cur_board.get_fitness()
    #print(cur_fit)
    
    start_time = time.time()
    orig_fitness = cur_fit
    
    while cur_fit != 0:    
        for i in range(0, BOARD_LENGTH):
            initial_pos = find_queen_position(cur_board.get_map(), cur_row)
            cur_board.flip(cur_row, i)
            cur_board.flip(cur_row, initial_pos)

            # If fitness increases, return board to original positoons
            if cur_board.get_fitness() > cur_fit:
                cur_board.flip(cur_row, initial_pos)
                cur_board.flip(cur_row, i)
                #attempts += 1
            # If not, keep new positions and update current fitness
            else:
                cur_fit = cur_board.get_fitness()
        
        cur_row = (cur_row + 1) % BOARD_LENGTH
        
        if cur_row == 0 and cur_fit != 0 and orig_fitness > cur_fit:
            # we have iterated through all the rows, is cur_fit better than orig_fit?
            # if not, we may be stuck in a local optima
            cur_board = board.Board(BOARD_LENGTH)
            cur_fit = cur_board.get_fitness()
            orig_fitness = cur_fit
            restarts += 1
        #print(cur_board.get_fitness())
    
    end_time = time.time()
    elapsed_time = (end_time - start_time) * 1000  # Convert to milliseconds

    print(f"Running time: {elapsed_time:.0f}ms")
    # print(f"Restarts: {restarts}") # TODO: comment this out, its not suppose to be part of the output!@

    for row in cur_board.get_map():
        print(' '.join('-' if x == 0 else '1' for x in row))

if __name__ == '__main__':
    main()
from board import Board
from random import randint
import time

def print_board(board):
    board_map = board.get_map()
    for row in board_map:
        print(' '.join(['1' if cell == 1 else '-' for cell in row]))

def generate_random_state():
    new_board = Board(5)
    return new_board

def hill_climbing(board):
    solution_found = False

    start = time.time()
    successor_fitness = board.get_fitness()

    if successor_fitness != 0:
        while not solution_found:
            # random restart mechanism
            board = generate_random_state()

            # generate new col. position for each queen
            for row in range(board.n_queen):
                new_col_pos = randint(0, board.n_queen - 1)  # rand. col number
                for col in range(board.n_queen):
                    board.map[row][col] = 0  # set all row numbers to 0

                board.map[row][new_col_pos] = 1
                current_fitness = board.get_fitness()

                # if current has higher fitness
                if current_fitness > successor_fitness:
                    successor_fitness = current_fitness  # current becomes successor
                elif current_fitness == 0:
                    solution_found = True
                    break

    end = time.time()
    d = int((end - start) * 1000)

    return d, board

if __name__ == '__main__':
    myBoard = Board(5)
    time, solution = hill_climbing(myBoard)
    print(f'Running time: {time}ms')
    print_board(solution)


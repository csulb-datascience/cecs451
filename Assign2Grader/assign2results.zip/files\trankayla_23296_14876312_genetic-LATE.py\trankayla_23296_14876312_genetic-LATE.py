import board
import random
import time
import math

def generate_q_strings(state):
    state.map = [[0 for j in range(state.n_queen)] for i in range(state.n_queen)]
    q_string = [0] * state.n_queen
    for column in range(state.n_queen):
        row = random.randint(0, state.n_queen - 1)
        state.map[row][column] = 1
        q_string[column] = state.n_queen - row
    return q_string

def q_string_to_board(q_string):
    b = board.Board(len(q_string))
    for i in range(b.n_queen):
        for j in range(b.n_queen):
            if b.get_map()[i][j] == 1:
                b.flip(i,j)
    column = 0
    while column < len(q_string):
        q_position = q_string[column]
        row = b.n_queen -q_position
        b.get_map()[row][column] = 1
        column += 1
    return b


def fitness(state):
    fit = 0
    for i in range(state.n_queen):
        for j in range(state.n_queen):
            if state.get_map()[j][i] == 1:
                for k in range(1, state.n_queen - i):
                    if state.get_map()[j][i + k] == 1:
                        fit += 1
                    if j - k >= 0 and state.get_map()[j-k][i+k] == 1:
                        fit += 1
                    if j + k < state.n_queen and state.get_map()[j + k][i + k] == 1:
                        fit += 1
    return fit

def genetic(states):
    start = time.time()
    while True:
        states = []
        for i in range(8):
            b = board.Board(queens)
            state = generate_q_strings(b)
            states.append(state)

        initial_population = []
        for state in states:
            b = q_string_to_board(state)
            total_pairs = math.comb(b.n_queen, 2)
            non_attacking_pairs = total_pairs - fitness(b)
            initial_population.append(non_attacking_pairs)

        probabilities = []
        for i in range(len(states)):
            probabilities.append(round(initial_population[i] / sum(initial_population), 2))

        parents = []
        for i in range(len(states)):
            r = random.random()
            if r <= probabilities[0]:
                parents.append(states[0])
            elif r <= sum(probabilities[:2]):
                parents.append(states[1])
            elif r <= sum(probabilities[:3]):
                parents.append(states[2])
            elif r <= sum(probabilities[:4]):
                parents.append(states[3])
            elif r <= sum(probabilities[:5]):
                parents.append(states[4])
            elif r <= sum(probabilities[:6]):
                parents.append(states[5])
            elif r <= sum(probabilities[:7]):
                parents.append(states[6])
            else:
                parents.append(states[7])

        children = []
        for i in range(0, len(states), 2):
            crossover_point = random.randint(1,3)
            children.append(parents[i][:crossover_point] + parents[i+1][crossover_point:])
            children.append(parents[i+1][:crossover_point] + parents[i][crossover_point:])

        mutated_children = []
        for idx in range(len(children)):
            if random.random() < .1:
                mut_index = random.randint(0,len(children[idx]) - 1)
                mut_position = random.randint(1,len(children[idx]))
                mutated_children.append(children[idx][:mut_index] + [mut_position] + children[idx][mut_index + 1:])
            else:
                mutated_children.append(children[idx])

        for i in range(len(initial_population)):
            if initial_population[i] == math.comb(queens,2):
                best_board = q_string_to_board(states[i])
                end = time.time()
                print("Running time: ", round((end - start) * 1000), "ms")
                return best_board


if __name__ == "__main__":
    queens = 5
    solution = genetic(queens)
    if fitness(solution) == 0:
        for row in solution.get_map():
            print(" ".join("1" if spot == 1 else "-" for spot in row))
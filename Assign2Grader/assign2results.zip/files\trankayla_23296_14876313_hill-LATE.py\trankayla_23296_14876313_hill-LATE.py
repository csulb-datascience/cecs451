import board
import time

def hill_climbing(problem):

    while True:
        best_fitness = problem.get_fitness()
        best_position = None

        if best_fitness == 0:
            return problem

        for i in range(problem.n_queen):
            for j in range(problem.n_queen):
                if problem.get_map()[i][j] == 1:
                    for k in range(problem.n_queen):
                        if k != j:
                            problem.flip(i,j)
                            problem.flip(i,k)
                            temp = problem.get_fitness()
                            if temp < best_fitness:
                                best_fitness = temp
                                best_position = (i, j, i, k)
                            problem.flip(i, k)
                            problem.flip(i, j)

        if best_fitness >= problem.get_fitness():
            return problem

        else:
            problem.flip(best_position[0], best_position[1])
            problem.flip(best_position[2], best_position[3])


if __name__ == "__main__":
    queens = 5
    start = time.time()
    solution = hill_climbing(board.Board(queens))
    end = time.time()
    print("Running time: ", round((end-start) * 1000), "ms")
    for row in solution.get_map():
        print(" ".join("1" if spot == 1 else "-" for spot in row))
import board
import random
import time


def hill_climb():
    initial_board = board.Board(5)
    fitness = initial_board.get_fitness()

    while fitness != 0:
        attempts = 0
        initial_board = board.Board(5)
        fitness = initial_board.get_fitness()

        while attempts < 25:
            row = random.randint(0, 4)
            starting_queen_index = initial_board.get_map()[row].index(1)
            initial_board.flip(row, starting_queen_index)
            updated_queen_index = starting_queen_index

            for i in range(5):
                initial_board.flip(row, i)
                current_fitness = initial_board.get_fitness()

                if current_fitness < fitness:
                    updated_queen_index = i
                    fitness = current_fitness

                initial_board.flip(row, i)

            initial_board.flip(row, updated_queen_index)

            attempts += 1
    return initial_board.get_map()


def display(self):
    for row in self.map:
        for element in row:
            if element == 1:
                print("1", end=" ")
            else:
                print("-", end=" ")
        print()


start_time = time.time()
solution = hill_climb()
end_time = time.time()
runtime = (end_time - start_time) * 1000
print(f"runtime: {runtime:.2f}ms")

for row in solution:
    for pos in row:
        if pos == 1:
            print("1", end=" ")
        else:
            print("-", end=" ")
    print()




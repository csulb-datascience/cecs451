import time
from board import Board
import random

start_time = time.time()
BOARD_SIZE = 4


def print_board(board_print):
    runtime = (time.time() - start_time) * 1000
    print("Running time:", '{0:.0f}'.format(runtime) + "ms")
    for row in board_print.get_map():
        for value in row:
            if value == 0:
                print("-", end=' ')
            else:
                print(value, end=' ')
        print()


def genetic_alg(population, fitness):
    correct_answer = BOARD_SIZE * (BOARD_SIZE - 1) / 2
    new_population = population
    # while we haven't found the correct answer
    infinite_loop = 0
    while correct_answer not in fitness:
        # create weights
        weights = {}
        for j in range(len(fitness)):
            weights[new_population[j]] = (fitness[j] / sum(fitness))
        # create population 2
        population2 = []
        fitness.clear()
        # sort population by weights
        #weights = dict(reversed(sorted(weights.items(), key=lambda item: item[1])))
        # loop through whole population
        for j in range(len(new_population)):
            # get both parents (randomly but weighted)
            parent1 = choose_parents(weights)
            parent2 = choose_parents(weights)
            # create child with parents
            child = reproduce(parent1, parent2)
            # chance of mutation
            mutate(child, 10)
            if infinite_loop > 1000:
                return False
            # add child to new population
            population2.append(child)
            # get fitness values for new population
            fitness.append(child.get_fitness())
        # assign new population
        new_population = population2
        # get non-attacking version of fitness
        non_attacking_pairs(fitness)
        infinite_loop += 1
    # once exited the loop the optimal board is found, loop through and return it
    for i in range(len(fitness)):
        if fitness[i] == correct_answer:
            return new_population[i]


def mutate(board, rate):
    #for row in range(BOARD_SIZE):
    # 1/10 chance that the child mutates
    chance = random.randrange(rate)
    map = board.get_map()
    if chance == 1:
        # choose random row
        row = random.randrange(BOARD_SIZE - 1)
        # get rid of the queen in that row
        for i in range(BOARD_SIZE):
            if map[row][i] == 1:
                board.flip(row, i)
        # flip random bit in that row for new queen
        board.flip(row, random.randrange(BOARD_SIZE - 1))


def encode(board):
    map = board.get_map()
    # create list to get encoding of board
    encoded = []
    for i in range(BOARD_SIZE):
        for j in range(BOARD_SIZE):
            if map[i][j] == 1:
                # append the index of the column in the row for the encoding
                encoded.append(j)
    return encoded


def reproduce(parent1, parent2):
    # get split value
    split = random.randrange(1, BOARD_SIZE - 1)
    # create new board
    child = Board(BOARD_SIZE)
    map = child.get_map()
    # reset new board to blank canvas
    for i in range(BOARD_SIZE):
        for j in range(BOARD_SIZE):
            if map[i][j] == 1:
                child.flip(i,j)
    # encode parents
    encoded1 = encode(parent1)
    encoded2 = encode(parent2)
    # create child from parents into new board
    for i in range(BOARD_SIZE):
        # before split copy parent 1
        if i < split:
            child.flip(i, encoded1[i])
        # after split copy parent 2
        else:
            child.flip(i, encoded2[i])
    return child


def choose_parents(weights):
    # randomly chooses a value between 0-1
    rand = random.uniform(0, 1)
    weight_sum = 0
    # loops through possible parents by weights
    for board, weight in weights.items():
        weight_sum += weight
        if rand <= weight_sum:
            return board


def non_attacking_pairs(fitness):
    # finds the compliment of attacking pairs to get non-attacking pairs
    for i in range(len(fitness)):
        fitness[i] = (BOARD_SIZE * (BOARD_SIZE - 1) / 2) - fitness[i]


if __name__ == '__main__':
    # create board
    while True:
        population = []
        fitness = []
        for i in range(8):
            population.append(Board(BOARD_SIZE))
            fitness.append(population[i].get_fitness())
        # calculate true fitness (non-attacking pairs)
        non_attacking_pairs(fitness)
        # do genetic alg
        answer = genetic_alg(population, fitness)
        if answer:
            break
    # print answer
    print_board(answer)

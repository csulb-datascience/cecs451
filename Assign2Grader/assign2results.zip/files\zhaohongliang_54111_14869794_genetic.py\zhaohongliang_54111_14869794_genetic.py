import time
import random
from board import Board


def create_boards(num):   # Done
    boards = []
    for _ in range(num):
        boards.append(Board(5))
    return boards


def selection(boards):    # Done
    board = sorted(boards, key=lambda b: b.get_fitness())

    half = len(board) // 2
    arr = []
    for i in range(half):
        arr.append(board[i])

    return arr


def crossover(board1, board2):  # Done

    b1 = Board(board1.n_queen)
    b2 = Board(board2.n_queen)

    point = random.randint(1, board1.n_queen - 2)

    # merge part of table from board1 and board2
    b1.map = board1.map[:point] + board2.map[point:]
    b2.map = board2.map[:point] + board1.map[point:]

    return b1, b2


def mutation(board, rate):  # Done
    num = random.random()

    if num < rate:
        board.flip(random.randint(0, board.n_queen - 1), random.randint(0, board.n_queen - 1))


def genetic_algorithm(num, rate):

    boards = create_boards(num)

    res = 0

    while True:
        better_boards = selection(boards)

        arr = []

        while len(arr) < num:
            b1, b2 = random.sample(better_boards, 2)
            c1, c2 = crossover(b1, b2)
            arr.append(c1)
            arr.append(c2)

        for b in arr:
            mutation(b, rate)

        boards = arr

        # find smaller value of fitness in boards
        b = boards[0]
        for board in boards:
            if board.get_fitness() < b.get_fitness():
                b = board

        if b.get_fitness() == 0:
            return b.get_map()

        res += 1


def main():
    size = 100
    rate = 0.001

    start = time.time()
    res = genetic_algorithm(size, rate)
    end = time.time()

    print("Running time: {:.0f}ms".format((end - start) * 1000))

    if res:
        for row in res:
            r = ''
            for ele in row:
                r += '_' if ele == 0 else '1'
                r += ' '
            print(r.strip())


if __name__ == "__main__":
    main()
